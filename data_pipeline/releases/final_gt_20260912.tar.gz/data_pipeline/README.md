# 最终版数据生产管线

当前版本：**final_gt_20260912**。本目录是数据管线的统一入口。
先读 [最终流程与人工检查顺序](docs/FINAL_PIPELINE.md)，再按下表查看代码。
冻结代码包和逐文件哈希位于 [releases/](releases/README.md)。

## 核心代码

| 顺序 | 文件 | 人工检查重点 |
|---|---|---|
| 1 | [run.sh](run.sh)、[configs/pointing.json](configs/pointing.json) | 本机环境、数据路径、相机入口、点位配置 |
| 2 | [collect_r2r.py](collect_r2r.py) | R2R 专家回放、RGB/深度/位姿采集、写出全部 GT |
| 3 | [geometry.py](geometry.py) | FM-30 路点与逐步 SE(2) 增量、RVQ-10 编码、路线偏差 |
| 4 | [pointing.py](pointing.py) | apos 十步目标与回退、opos 固定终点、深度可见性、像素/网格 |
| 5 | [annotate_r2r.py](annotate_r2r.py) | 已有原始轨迹的 CPU 补标，保存独立版本 |
| 6 | [validate_r2r.py](validate_r2r.py)、[validate_pointing.py](validate_pointing.py) | 帧对齐、源哈希、独立 mask、几何和 token 检查 |
| 7 | [visual/render_episode_gt.py](../visual/render_episode_gt.py) | GT 轨迹、同心 apos/opos 标记、视频及像素格子图 |

共享依赖：[RVQ 解码器](../src/lightnav/traj_vocab.py)、
[网格 token 工具](../src/lightnav/vln_utils.py)、
[LightNav 相机/运动配置](../habitat_server/configs/vlnce_r2r.yaml)。

## 固定的生成定义

```text
R2R 场景、起点、指令和专家 GT 路线
  → LightNav 配置的 Habitat-Sim 回放
  → 每步新的 RGB、深度、机体和相机位姿
  → FM：未来 30 步真实路点 + 逐步运动增量
  → RVQ：同一轨迹前 10 步 → 三层码本索引 + 解码轨迹
  → apos：min(t+10,N-1) 地面目标；必要时沿未来 GT 路径回退
  → opos：固定为实际末帧的三维地面位置
  → 每类独立 mask、像素与 48×27 网格、数据与代码来源记录
  → 验证 → 视频 / 人工检查
```

- RGB/深度原生 470×280，HFOV 120°，相机高 0.88 m、俯仰 0°。
- 运动量采用前向米、左向米、逆时针 yaw 弧度；FM 不使用 RVQ 重建轨迹当 GT。
- 一个 step 是一次实际专家采样转移，包含原地转向；physical_dt_s=null。
- 新样本不输出前进/左转/右转类别。RVQ 的显式 STOP 监督保留。
- apos 与 opos 在不可见时仍保存三维目标；缺失像素不会伪造为图像边缘点。
- FM、RVQ、apos、opos 分别使用自己的 mask；完整定义见 [GT_CONSTRUCTION.md](docs/GT_CONSTRUCTION.md)。
- 新采集和补标只生成 terminal_ground + terminal，当前流程无需豆包或语义建模。
- 原始数据和大型生成结果保存在 /mnt/cfs/data/beta_nav，已有数据不覆盖。

## 运行

在仓库根目录运行；输出路径必须是新目录。

```bash
# 只检查采集配置，不渲染、不生成数据；本机 Habitat 环境由 run.sh 指定
bash data_pipeline/run.sh /mnt/cfs/data/beta_nav/NEW_RUN 1 --dry-run

# 从 R2R 回放并同时生成全部四类 GT
bash data_pipeline/run.sh /mnt/cfs/data/beta_nav/NEW_RUN 10

# 已有完整原始轨迹：CPU 重新生成 apos/opos，复用运动 GT
.venv/bin/python data_pipeline/annotate_r2r.py \
  /mnt/cfs/data/beta_nav/r2r_train_470x280_20260911 \
  --output-dir /mnt/cfs/data/beta_nav/NEW_POINTING_RUN \
  --episode-id 2864 --episodes 1

# 只读验证
.venv/bin/python data_pipeline/validate_r2r.py /mnt/cfs/data/beta_nav/NEW_POINTING_RUN

# 人工检查视频
.venv/bin/python visual/render_episode_gt.py \
  /mnt/cfs/data/beta_nav/NEW_POINTING_RUN/episodes/2864 \
  --output /mnt/cfs/data/beta_nav/visual/NEW_GT.mp4 --fps 5 --horizon 10 --scale 2

# CPU 测试
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python -m pytest -q data_pipeline/tests
```

采集参数见 [R2R_COLLECTION.md](docs/R2R_COLLECTION.md)，补标参数见
[POINTING.md](docs/POINTING.md)，视频参数见 [VISUALIZATION.md](docs/VISUALIZATION.md)。
Habitat 使用独立 Python 3.9 环境，离线补标和视频可使用仓库 .venv。

## 辅助工具与资料

- [export_pointing_grid.py](export_pointing_grid.py)：旧标注升级像素/网格字段并导出 CSV。
- [rollout_lightnav.py](rollout_lightnav.py)：真实模型闭环预测与视频，使用方法见
  [LIGHTNAV_ROLLOUT.md](docs/LIGHTNAV_ROLLOUT.md)；其输出不作为专家 GT。
- [GT_CONSTRUCTION.md](docs/GT_CONSTRUCTION.md)：数组语义、单位、mask 与完整数值例子。
- [INTERNNAV_FM_COMPARISON.md](docs/INTERNNAV_FM_COMPARISON.md)：与 InternNav 的运动定义对照。
- [HISTORY.md](docs/HISTORY.md)：历史数据路径和各次生成记录；reports/ 保存小型报告。
- [archive/](archive/README.md)：清理前的代码和文档，不参与当前运行。
- 本机 config.py 仅保留账户配置，当前 GT 流程不读取它；不进入 Git、快照或代码包。

当前可人工检查的数据：
/mnt/cfs/data/beta_nav/r2r_2864_opos_endpoint_20260912/episodes/2864。
其 52 帧中 apos 可见 38 帧；opos 可见 36 帧、不可见 16 帧。
视频为 /mnt/cfs/data/beta_nav/visual/episode_2864_gt_opos_endpoint_rings_20260912.mp4。
历史兼容入口 scripts/collect_beta_nav.py 保留，其实现转发到本目录。
