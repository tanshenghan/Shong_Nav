"""Final destination annotation, CPU entry point and historical read compatibility."""

import json
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from data_pipeline.annotate_r2r import annotate_episode, provenance_code_paths
from data_pipeline.pointing import PointingConfig, terminal_ground_point
from data_pipeline.validate_pointing import validate_pointing


def make_source(tmp_path, *, moving=True):
    source = tmp_path / "source" / "episodes" / "test"
    source.mkdir(parents=True)
    (source.parents[1] / "manifest.json").write_text("{}")
    frames = []
    K = np.array([[50., 0, 50.], [0, 50., 50.], [0, 0, 1.]])
    for i in range(12):
        body = np.eye(4)
        body[2, 3] = -i * .25 if moving else 0.
        camera = body @ np.diag([1., -1., -1., 1.])
        camera[1, 3] = .88
        Image.new("RGB", (100, 100)).save(source / f"{i}.png")
        np.savez(source / f"{i}.npz", depth_m=np.full((100, 100), 2.), valid=np.ones((100, 100), bool))
        frames.append(dict(frame_id=i, rgb=f"{i}.png", depth=f"{i}.npz",
                           world_from_body=body.tolist(), world_from_camera_cv=camera.tolist()))
    (source / "frames.jsonl").write_text("\n".join(json.dumps(f) for f in frames))
    (source / "samples.jsonl").write_text("\n".join(json.dumps(dict(frame_id=i, history_end_inclusive=i))
                                                       for i in range(12)))
    (source / "episode.json").write_text(json.dumps(dict(complete=True, frames=12, episode_id="test",
        scene_id="synthetic", instruction="Stop just inside the doorway.",
        camera=dict(width=100, height=100, K=K.tolist()))))
    np.savez(source / "targets.npz", fm_clean_se2_diff=np.zeros((12, 30, 3)))
    return source, frames, K



def test_opos_keeps_the_same_endpoint_when_occluded_or_beneath_camera(tmp_path):
    source, _, _ = make_source(tmp_path)

    folder = tmp_path / "labels"
    result = annotate_episode(source, folder, PointingConfig())
    assert result["opos_bound"] and result["opos_search"] is None
    assert not result["object_bound"] and result["opos_visible"] > 0
    assert not (folder / "detections").exists()
    rows = [json.loads(s) for s in (folder / "samples.jsonl").read_text().splitlines()]
    assert all(r["opos"]["target_world_point"] == [0., 0., -2.75] for r in rows)
    assert all(r["opos"]["target_frame_id"] == 11 for r in rows)
    assert rows[0]["apos"]["target_frame_id"] == 10
    assert rows[0]["opos"]["state"] == "not_visible"  # occluded by depth at 2 m
    assert rows[-1]["opos"]["state"] == "not_visible"  # beneath the terminal camera
    assert rows[-1]["opos"]["pixel"] is None
    with np.load(folder / "targets.npz") as data:
        np.testing.assert_array_equal(data["opos_target_frame_id"], np.full(12, 11))
        np.testing.assert_array_equal(data["opos_target_world"], np.tile([0., 0., -2.75], (12, 1)))



def test_default_annotation_cli_needs_neither_api_config_nor_semantic_assets(tmp_path, monkeypatch):
    import data_pipeline.annotate_r2r as annotate

    source, _, _ = make_source(tmp_path)
    output = tmp_path / "default_run"

    original_read_text = Path.read_text

    def guarded_read_text(path, *args, **kwargs):
        if path.name == "config.py":
            pytest.fail("final annotation must not read local API configuration")
        return original_read_text(path, *args, **kwargs)

    monkeypatch.setattr(Path, "read_text", guarded_read_text)
    monkeypatch.setattr("sys.argv", ["annotate_r2r.py", str(source.parents[1]),
                        "--output-dir", str(output)])
    annotate.main()
    report = json.loads((output / "manifest.json").read_text())
    assert report["opos_mode"] == "terminal_ground" and not report["api_requested"]
    assert validate_pointing(output)["opos_visible"] > 0


@pytest.mark.parametrize("config", [PointingConfig(opos_mode="doubao"), PointingConfig(tail_policy="mask")])
def test_generation_rejects_retired_definitions_before_creating_output(tmp_path, config):
    source, _, _ = make_source(tmp_path)
    output = tmp_path / "retired"
    with pytest.raises(ValueError, match="final GT generation requires"):
        annotate_episode(source, output, config)
    assert not output.exists()


def test_provenance_excludes_credentials_and_retired_modules(tmp_path):
    for name in ("config.py", "doubao.py", "annotate_r2r.py", "pointing.py"):
        (tmp_path / name).write_text("placeholder")
    assert [p.name for p in provenance_code_paths(tmp_path)] == ["annotate_r2r.py", "pointing.py"]
    historical = PointingConfig.from_metadata({})
    assert historical.tail_policy == "mask" and historical.opos_mode == "doubao"
    assert historical.opos_search_frames == 1
    assert "opos_search_frames" not in PointingConfig().metadata()


def test_opos_invalid_depth_keeps_endpoint_and_masks_pixel(tmp_path):
    _, frames, K = make_source(tmp_path)
    positions = np.asarray([f["world_from_body"] for f in frames])[:, :3, 3]
    point = terminal_ground_point(positions, frames[0]["world_from_camera_cv"], K,
                                  np.full((100, 100), 3.), np.zeros((100, 100), bool), PointingConfig())
    assert point["state"] == "unknown" and not point["loss_valid"]
    assert point["target_world_point"] == positions[-1].tolist()
    assert point["pixel"] is None and point["token_id"] == -1
