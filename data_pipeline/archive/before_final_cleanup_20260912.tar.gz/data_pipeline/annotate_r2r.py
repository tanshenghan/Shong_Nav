#!/usr/bin/env python3
"""Annotate apos-10 and final-destination opos in a NEW dataset overlay."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from dataclasses import replace
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(REPO))

from data_pipeline.collect_r2r import sha256, write_json  # noqa: E402
from data_pipeline.destination import find_destination  # noqa: E402
from data_pipeline.doubao import DoubaoGrounder, load_api_settings  # noqa: E402
from data_pipeline.pointing import (  # noqa: E402
    PointingConfig,
    attach_pixel_grid,
    fixed_world_point,
    ground_point,
    ground_target_arrays,
    object_point,
    pixel_grid_arrays,
    pixel_grid_metadata,
    terminal_ground_point,
    unknown_point,
)


def provenance_code_paths(directory):
    """Snapshot executable pipeline code only; local config.py contains secrets."""
    names = ("__init__.py", "annotate_r2r.py", "collect_r2r.py", "destination.py", "doubao.py", "export_pointing_grid.py", "geometry.py",
             "pointing.py", "semantic_scene.py", "validate_pointing.py", "validate_r2r.py")
    return [directory / name for name in names if (directory / name).is_file()]


def read_episode(folder):
    episode = json.loads((folder / "episode.json").read_text())
    if not episode.get("complete"):
        raise ValueError(f"incomplete source episode: {folder.name}")
    frames = [json.loads(s) for s in (folder / "frames.jsonl").read_text().splitlines()]
    samples = [json.loads(s) for s in (folder / "samples.jsonl").read_text().splitlines()]
    if not frames or len(frames) != len(samples) or len(frames) != episode["frames"]:
        raise ValueError("source frame/sample counts disagree")
    if [f["frame_id"] for f in frames] != list(range(len(frames))):
        raise ValueError("source frame IDs must be contiguous")
    return episode, frames, samples


def draw_preview(image_path, output, apos=None, opos=None, detection=None):
    with Image.open(image_path) as image:
        image = image.convert("RGB")
    draw = ImageDraw.Draw(image)
    if detection and detection["found"]:
        w, h = image.size
        box = (np.asarray(detection["bbox_xyxy"]) * [w, h, w, h]).tolist()
        draw.rectangle(box, outline=(255, 80, 160), width=2)
    for point, color in [(apos, (80, 255, 180)), (opos, (255, 80, 160))]:
        if point and point["state"] == "point":
            x, y = point["pixel"]
            draw.ellipse([x - 4, y - 4, x + 4, y + 4], fill=color, outline="white")
    image.save(output)


def annotate_episode(source, destination, config, *, grounder=None, replay=None, apos_only=False):
    episode, frames, samples = read_episode(source)
    destination.mkdir(parents=True, exist_ok=False)
    camera = episode["camera"]
    poses = np.asarray([f["world_from_body"] for f in frames])
    K = np.asarray(camera["K"])
    binding = {"bound": False, "reason": "apos_only_requested"}
    selected_semantic, selected_alignment, mesh = None, None, None
    search = None
    if not apos_only and config.opos_mode == "terminal_ground":
        binding = dict(bound=True, target_type="stop_location", model_kind="recorded_terminal_ground_point",
                       world_point=poses[-1, :3, 3].tolist(), target_frame_id=len(frames) - 1,
                       anchor_frame_id=None, label="final destination",
                       reason="recorded_terminal_destination", confirmation="recorded_expert_endpoint")
    elif not apos_only:
        if grounder is None:
            raise ValueError("doubao mode requires a grounder; use apos_only=True to skip opos")
        found = find_destination(source, destination, episode, frames, config, grounder, replay)
        binding, mesh = found["binding"], found["mesh"]
        selected_semantic, selected_alignment = found["semantic"], found["alignment"]
        search = found["search"]
    apos, opos, rows, agreements = [], [], [], []
    with np.load(source / "targets.npz", allow_pickle=False) as original:
        targets = {k: original[k] for k in original.files if not k.startswith(("apos_", "opos_"))}
    for t, frame in enumerate(frames):
        with np.load(source / frame["depth"], allow_pickle=False) as depth:
            d, valid = depth["depth_m"], depth["valid"]
        a = ground_point(poses[:, :3, 3], t, frame["world_from_camera_cv"], K, d, valid, config)
        o = unknown_point(binding["reason"])
        if binding["bound"] and config.opos_mode == "terminal_ground":
            o = terminal_ground_point(poses[:, :3, 3], frame["world_from_camera_cv"], K, d, valid, config)
        elif binding["bound"] and binding.get("target_type") == "stop_location":
            o = fixed_world_point(binding["world_point"], frame["world_from_camera_cv"],
                                  K, d, valid, config)
        elif binding["bound"]:
            if t == binding["anchor_frame_id"]:
                semantic, agreement = selected_semantic, selected_alignment
            else:
                semantic, agreement = replay.observe(frame, d, valid)
            agreements.append(agreement)
            o = object_point(semantic, binding["semantic_id"], d, valid,
                             frame["world_from_camera_cv"], K, config, world_bounds=mesh["aabb_world"])
            # A coordinate mismatch must fail, not propagate plausible but unrelated pixels.
            if o["state"] == "point":
                point = np.asarray(o["world_point"])
                bounds = mesh["aabb_world"]
                if np.any(point < bounds[0] - .15) or np.any(point > bounds[1] + .15):
                    raise ValueError("visible instance point is outside its world mesh; check semantic axes/IDs")
            np.savez_compressed(destination / "object_masks" / f"{t:06d}.npz",
                                visible_mask=semantic == binding["semantic_id"])
        a = attach_pixel_grid(a, d.shape[1], d.shape[0])
        o = attach_pixel_grid(o, d.shape[1], d.shape[0])
        apos.append(a)
        opos.append(o)
        # Whitelist the training interface: old replay-action fields are not carried forward.
        row = {k: samples[t][k] for k in ("frame_id", "history_start", "history_end_inclusive",
               "rvq_codes", "rvq_tokens", "rvq_loss_valid", "fm_valid_steps", "explicit_stop",
               "stop_loss_valid") if k in samples[t]}
        row.update(current_rgb=str((source / frame["rgb"]).resolve()),
                   current_depth=str((source / frame["depth"]).resolve()),
                   array_file="targets.npz", array_row=t, apos=a, opos=o,
                   apos_tokens=f"<apos_{a['token_id']}>" if a["loss_valid"] else None,
                   opos_tokens=f"<opos_{o['token_id']}>" if o["loss_valid"] else None)
        rows.append(row)
        if t in {0, len(frames) // 2, len(frames) - 1}:
            draw_preview(source / frame["rgb"], destination / f"preview_{t:06d}.png", a, o)
    for name, points in [("apos", apos), ("opos", opos)]:
        targets[name + "_pixel"] = np.asarray([p["pixel"] if p["state"] == "point"
                                               else [np.nan] * 2 for p in points], dtype=np.float32)
        targets[name + "_world"] = np.asarray([p["world_point"] if p["state"] == "point"
                                               else [np.nan] * 3 for p in points], dtype=np.float32)
        targets[name + "_token_id"] = np.asarray([p["token_id"] for p in points], dtype=np.int32)
        targets[name + "_valid_mask"] = np.asarray([p["loss_valid"] for p in points], dtype=bool)
        targets.update(pixel_grid_arrays(points, name))
    targets.update(ground_target_arrays(apos))
    targets.update(ground_target_arrays(opos, "opos"))
    np.savez_compressed(destination / "targets.npz", **targets)
    with (destination / "samples.jsonl").open("x") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
    write_json(destination / "object_binding.json", binding)
    result = {"complete": True, "source_episode": str(source.resolve()),
              "episode_id": episode["episode_id"], "scene_id": episode["scene_id"],
              "instruction": episode["instruction"], "frames": len(frames), "camera": camera,
              "object_bound": binding["bound"] and binding.get("target_type") == "object",
              "opos_bound": binding["bound"], "opos_target_type": binding.get("target_type"),
              "opos_search": search, "pointing_config": config.metadata(),
              "pointing_grid": pixel_grid_metadata(d.shape[1], d.shape[0]),
              "apos_valid": sum(p["loss_valid"] for p in apos),
              "opos_valid": sum(p["loss_valid"] for p in opos),
              "opos_visible": sum(p["state"] == "point" for p in opos),
              "min_semantic_depth_agreement": min(agreements) if agreements else None,
              "source_hashes": {name: sha256(source / name) for name in
                                ["episode.json", "frames.jsonl", "targets.npz", "samples.jsonl"]}}
    write_json(destination / "episode.json", result)
    return result


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", type=Path, help="Existing complete beta_nav collection")
    parser.add_argument("--output-dir", type=Path, required=True, help="NEW annotation overlay directory")
    parser.add_argument("--config", type=Path, default=REPO / "data_pipeline/configs/pointing.json")
    parser.add_argument("--episodes", type=int, default=10, help="At most this many episodes; -1 for all")
    parser.add_argument("--episode-id", help="Annotate exactly one source episode")
    parser.add_argument("--apos-only", action="store_true", help="Explicitly skip API/semantic replay; opos remains unknown")
    parser.add_argument("--opos-mode", choices=["terminal_ground", "doubao"],
                        help="Override config: final recorded destination (CPU default) or legacy Doubao grounding")
    parser.add_argument("--doubao-model", help="Override environment/config.py vision model")
    parser.add_argument("--api-key-env", help="Use this credential environment variable exclusively")
    parser.add_argument("--api-base-url", help="Override environment/config.py HTTPS API URL")
    parser.add_argument("--detection-cache-dir", type=Path, help="Reuse identity-checked API responses across new runs")
    parser.add_argument("--scenes-dir", type=Path,
                        default=Path(os.environ.get("BETA_SCENES_DIR", "/mnt/cfs/data/habitat/scene_datasets")))
    parser.add_argument("--scene-dataset-config", type=Path, help="MP3D dataset config; defaults under scenes-dir/mp3d")
    parser.add_argument("--gpu-id", type=int, default=int(os.environ.get("BETA_GPU_ID", "3")))
    parser.add_argument("--dry-run", action="store_true", help="Inspect inputs/config only; no API, render or writes")
    args = parser.parse_args()
    if args.episodes == 0 or args.episodes < -1:
        parser.error("episodes must be positive or -1")
    return args


def main():
    args = arguments()
    source = args.dataset.resolve()
    if args.output_dir.exists():
        raise FileExistsError("annotation output must be a new directory")
    config = PointingConfig(**json.loads(args.config.read_text()))
    if args.opos_mode:
        config = replace(config, opos_mode=args.opos_mode)
    use_doubao = not args.apos_only and config.opos_mode == "doubao"
    manifest = json.loads((source / "manifest.json").read_text())
    folders = sorted((source / "episodes").iterdir())
    folders = [p for p in folders if p.is_dir() and (p / "episode.json").is_file()]
    if args.episode_id:
        folders = [p for p in folders if p.name == args.episode_id]
    if args.episodes > 0:
        folders = folders[:args.episodes]
    if not folders:
        raise ValueError("no matching complete source episodes")
    records = [(p, read_episode(p)[0]) for p in folders]
    records.sort(key=lambda pair: (pair[1]["scene_id"], pair[0].name))
    scene_config = args.scene_dataset_config or args.scenes_dir / "mp3d/mp3d.scene_dataset_config.json"
    if use_doubao:
        if not scene_config.is_file():
            raise FileNotFoundError(scene_config)
        for _, ep in records:
            scene = args.scenes_dir / ep["scene_id"].removeprefix("data/scene_datasets/")
            for path in [scene, scene.with_suffix(".house"), scene.with_name(scene.stem + "_semantic.ply")]:
                if not path.is_file():
                    raise FileNotFoundError(path)
    settings = {} if not use_doubao else load_api_settings(
        model=args.doubao_model, base_url=args.api_base_url, key_env=args.api_key_env)
    code_paths = provenance_code_paths(REPO / "data_pipeline")
    report = {"format": "beta_nav_pointing_v1", "source_dataset": str(source),
              "source_manifest_sha256": sha256(source / "manifest.json"),
              "pointing_config": config.metadata(), "episodes": [p.name for p, _ in records],
              "pointing_grid": pixel_grid_metadata(records[0][1]["camera"]["width"],
                                                    records[0][1]["camera"]["height"]),
              "opos_requested": not args.apos_only, "doubao_model": settings.get("model"),
              "opos_mode": config.opos_mode, "api_requested": use_doubao,
              "discrete_action_labels": False, "rgb_depth_storage": "referenced from source, unmodified",
              "scene_dataset_config": str(scene_config) if use_doubao else None,
              "scene_dataset_config_sha256": sha256(scene_config) if use_doubao else None,
              "api_base_url": settings.get("base_url"),
              "detection_cache_dir": str(args.detection_cache_dir) if args.detection_cache_dir else None,
              "code_sha256": {p.name: sha256(p) for p in code_paths}}
    if args.dry_run:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return
    grounder = None if not use_doubao else DoubaoGrounder(
        **settings, key_env=args.api_key_env or "ARK_API_KEY", cache_dir=args.detection_cache_dir)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    provenance = args.output_dir / "provenance"
    provenance.mkdir()
    for path in code_paths:
        shutil.copyfile(path, provenance / path.name)
    shutil.copyfile(args.config, provenance / "pointing_config.json")
    if use_doubao:
        shutil.copyfile(scene_config, provenance / "mp3d.scene_dataset_config.json")
    write_json(args.output_dir / "manifest.json", report)
    results, replay = [], None
    try:
        for folder, ep in records:
            scene = args.scenes_dir / ep["scene_id"].removeprefix("data/scene_datasets/")
            if grounder is not None and (replay is None or replay.scene != scene):
                if replay is not None:
                    replay.close()
                    replay = None
                from data_pipeline.semantic_scene import SemanticReplay

                replay = SemanticReplay(manifest["simulator_config"], scene, scene_config, args.gpu_id)
            result = annotate_episode(folder, args.output_dir / "episodes" / folder.name,
                                      config, grounder=grounder, replay=replay, apos_only=args.apos_only)
            results.append(result)
            print(json.dumps({k: result[k] for k in
                              ["episode_id", "frames", "apos_valid", "opos_visible", "object_bound"]}), flush=True)
        write_json(args.output_dir / "summary.json", {
            "complete": True, "episodes": len(results), "opos_requested": not args.apos_only,
            "frames": sum(r["frames"] for r in results),
            "bound_objects": sum(r["object_bound"] for r in results),
            "bound_destinations": sum(r["opos_bound"] for r in results),
            "apos_valid": sum(r["apos_valid"] for r in results),
            "opos_visible": sum(r["opos_visible"] for r in results)})
    except Exception as exc:
        write_json(args.output_dir / "failure.json", {"error": str(exc), "completed_episodes": len(results)})
        raise
    finally:
        if replay is not None:
            replay.close()


if __name__ == "__main__":
    main()
