# 单条 episode 的 GT 视频

按用户要求，渲染逻辑集中在仓库根目录的
[`visual/render_episode_gt.py`](../../visual/render_episode_gt.py) 一个 Python 文件中。
它独立读取磁盘数据，只需要 NumPy、Pillow、imageio 和 imageio-ffmpeg，
不依赖 Habitat、LightNav 模型或豆包 API。文档、测试和小型验证记录仍在 data_pipeline。

## 视频内容

- 顶部完整显示本条轨迹的 Instruction，按宽度自动换行。
- 将当前帧起点和真实未来 t+1 到 t+10 的机体地面位置连成线，使用当前帧
  `world_from_camera_cv` 与 K 投影到 RGB。位置来自保存的 `world_from_body`，
  保留楼梯的世界高度，不使用 RVQ 解码轨迹代替 GT。
- 蓝色实线表示深度检查可见的轨迹，橙色虚线表示被遮挡或深度无效的部分。
  先裁剪相机近面，再裁剪图像边界，不将相机后方的点强行画入图片。
- 绿色大圆环标 apos，粉色小圆环标 opos；两者重合时同心显示，文字分别放在
  左上与右下，中心保持真实像素，不移动标签。只画已保存且 `state=point`、
  `loss_valid=true` 的像素。不重新计算或伪造标签。
- 底部显示帧号、真实剩余未来步数和两个 pointing 通道的状态。
  unknown、not_visible、unavailable 没有像素标记，状态仍会显示。
- 右侧俯视图显示全部未来路点，当前机体朝前的方向为图中向上，白色三角形为
  当前机体、蓝线为未来路线。按机体 XZ 平面绘制，整段视频保持相同米制比例；
  RGB 视野外的路线也能在这里查看。侧栏不覆盖原始 RGB 或 pointing 标记。
- 原地旋转没有地面位移；最后一帧没有未来位置。此时不造轨迹线。
  尾部只画实际存在的步数，不重复填充末帧以凑满 10 步。

默认以 5 FPS 播放、将 470×280 RGB 等比例放大到 940×560，再增加顶部指令栏和
底部说明栏以及右侧俯视图。放大用于便于查看，不增加原图细节。FPS 只控制播放速度，不能解释为
R2R 专家动作的物理时间。输出采用 H.264 / yuv420p / faststart，便于播放器打开。

## 运行

在仓库根目录使用已有 `.venv`：

```bash
# 直接读取带 apos/opos 的新版 episode；它会引用原始 RGB、深度和位姿
.venv/bin/python visual/render_episode_gt.py \
  /mnt/cfs/data/beta_nav/r2r_2864_gt_20260911_v2/episodes/2864 \
  --output /mnt/cfs/data/beta_nav/visual/episode_2864_NEW.mp4

# 也可以从原始 episode 出发，明确指定对应标签目录
.venv/bin/python visual/render_episode_gt.py \
  /mnt/cfs/data/beta_nav/r2r_train_470x280_20260911/episodes/2864 \
  --annotations /mnt/cfs/data/beta_nav/r2r_2864_gt_20260911_v2/episodes/2864 \
  --output /mnt/cfs/data/beta_nav/visual/episode_2864_NEW.mp4 \
  --fps 5 --horizon 10 --scale 2
```

原始 episode 未指定 annotations 时，只绘制原始数据已有的标签；没有 apos/opos
就显示 unavailable。脚本不会猜测应该选哪个补标版本。
输出文件存在时拒绝覆盖。对原始数据和标签只做读取。

| 参数 | 默认值 | 含义 |
|---|---|---|
| `episode` | 必填 | 原始或新版补标的单条 episode 目录，包含 episode.json |
| `--annotations` | 无 | 为原始输入指定同一条轨迹的标注目录 |
| `--output` | 必填 | `.mp4` 输出视频及预览，`.png` 输出网格示意图；两种模式均保存 JSON |
| `--fps` | 5 | 视频播放帧率，0 < FPS ≤ 60 |
| `--horizon` | 10 | 未来轨迹步数，范围 1～30；不改变已有 apos 的定义 |
| `--scale` | 2 | RGB 整数显示倍率，范围 1～4 |
| `--font` | DejaVuSans | 可选 TrueType 字体文件；其他语言需使用支持相应字符的字体 |
| `--frame-id` | PNG 默认为 0 | 网格图的帧号；视频模式使用全部帧，不接受该参数 |
| `--channel` | apos | PNG 示意图选择 apos 或 opos |

## 单帧像素与网格示意图

同一个代码文件支持 PNG 输出：叠加 48×27 网格和从 0 开始的行列编号，
高亮所选 apos/opos 的空间格子，以白点显示精确像素，并提供局部放大图。
右侧列出原图像素、整数像素行列、网格行列、格子编号及 token。
未知标签会显示没有有效空间格子；不会为其补造位置。

```bash
.venv/bin/python visual/render_episode_gt.py \
  /mnt/cfs/data/beta_nav/r2r_2864_gt_grid_20260912/episodes/2864 \
  --output /mnt/cfs/data/beta_nav/visual/episode_2864_grid_NEW.png \
  --frame-id 0 --channel apos --scale 2
```

PNG 模式不使用 `--fps` 和 `--horizon`。网格位置以原始 RGB 为准，
显示放大与图片外边距不改变标签坐标。已有标签记录网格或 token 时，
绘图前检查它们与精确像素一致。
本次图片位于 `/mnt/cfs/data/beta_nav/visual/episode_2864_frame_000000_apos_grid_20260912.png`。

## 输出和检查

- `.mp4`：每个源观测对应一帧视频。
- `.png`：第一帧的无损预览。
- `.json`：输入路径、完整 Instruction、帧数、播放帧率、画面大小、代码/数据
  哈希以及每帧轨迹和 pointing 状态。

程序先核对源 episode、标签、相机和帧索引，检查补标记录的源文件哈希；
编码后再用 ffmpeg 核对总帧数。CPU 测试覆盖坐标变换、近面裁剪、遮挡、
尾部不足步数、有效/无效标记、错位标签拒绝及实际 MP4 编码。

历史 episode 2864 的视频（使用当时的豆包标签）：
`/mnt/cfs/data/beta_nav/visual/episode_2864_gt10_topview_20260911.mp4`。
原始数据为 52 帧；当时的标签有 38 个有效 apos，opos 全部 unknown，因此视频中
不会出现粉色物体点。这是本条数据的真实标注状态。

当前默认固定终点 opos 的视频为
`/mnt/cfs/data/beta_nav/visual/episode_2864_gt_opos_endpoint_20260912.mp4`。
使用 `r2r_2864_opos_endpoint_20260912/episodes/2864` 的新标签，38 帧有 apos，
第 11–46 帧共 36 帧有粉色 opos。opos 在所有帧对应同一个最终目的地。
第 44 帧网格图为
`/mnt/cfs/data/beta_nav/visual/episode_2864_frame_000044_opos_endpoint_grid_20260912.png`。

重合标记修正版视频为
`/mnt/cfs/data/beta_nav/visual/episode_2864_gt_opos_endpoint_rings_20260912.mp4`。
第 41–46 帧的 apos/opos 像素完全相同，旧视频后画的粉色圆点覆盖了绿色圆点；
现在以绿色外环、粉色内环同时显示。第 2–10、47–51 帧则是未来地面路线确实在
画面外，没有有效 apos 像素。逐帧标签保持不变，检查记录见
[缺失与重合诊断](../reports/episode_2864_apos_missing_and_overlap_20260912.json)。
