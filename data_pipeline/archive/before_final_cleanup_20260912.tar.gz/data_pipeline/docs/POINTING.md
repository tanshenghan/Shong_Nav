# 新版 apos / opos 数据管线

本方案按用户最新定义实现。采样仍沿用内部 R2R-VLNCE 专家动作回放；新采集和
补标样本不输出前进/左转/右转标签。实际位姿仍包含转向，RVQ/FM 的 yaw 不删除。
原有 RVQ 终止监督保留；apos 不输出转向或 STOP token。

## apos：第 10 步地面点

实现：[pointing.py](../pointing.py) 的 `ground_point()`。

1. 以新回放机体原点（脚底/navmesh 地面位置）`position[min(t+10, N-1)]` 为目标，保留实际
   世界高度，不把楼梯统一压到 y=0。相机高度不加到目标点上。
2. 用当前 `world_from_camera_cv` 的逆变换和 K 投影。
3. 要求 Z>0、在画面内、对应深度有效，且目标的 camera-Z 不大于观测深度加容差。
   默认容差为 0.05 m + 观测深度的 1%。
4. 若第 10 步不可见，沿 t+10 到 t 的未来轨迹反向搜索，每段插值间距不大于
   0.02 m。选择遇到的第一个可见点，即沿路径距离最接近原第 10 步目标的可见点。
   不选择任意最近的图像像素，也不把越界点裁剪到图像边缘。
5. 最后十帧不存在 t+10 时，统一使用末帧三维地面坐标作为目标，仍执行上述投影和
   遮挡检查。整段没有可见候选时，像素标签为 unknown、loss mask=false，但保留
   `target_world_point`，不会丢失末帧三维目标，也不会伪造图像内的像素。

每帧保留 `target_frame_id`、`target_world_point`；可见点还保留
`selected_frame_fraction`、`backtrack_m`。`terminal_ground_point` 表示直接使用末帧，
`t_plus_10` 表示直接使用第十步，`visible_path_backtrack` 表示遮挡回退。
`world_point` 是实际可见标记点，回退时可能位于两帧之间，与三维目标不同。
默认 `tail_policy=terminal`；旧数据未记录此字段时，验证器按旧版 `mask` 解释，
不更改历史数据的含义。此规则只改变 apos，RVQ/FM 的尾部有效 mask 不变。

这里的近处回退候选只来自当前到目标之间的 **GT 路线**。画面中存在其他可见地面，
不代表这段未来路线上的地面点也可见。第 2～10 帧的逐点/插值检查，以及整段线段
与相机视野的相交检查，见 [2864 近点报告](../reports/apos_2864_nearby_visibility_20260912.json)。
该例这九帧的候选均在视野外，因此没有可写入有效图像格子的 apos。

## opos：整条轨迹最终要到达的地方（当前默认）

`opos_mode=terminal_ground`，实现为 [pointing.py](../pointing.py) 的
`terminal_ground_point()`。设一条轨迹有 N 帧，第 t 帧使用的目标始终是：

```text
opos_target_world(t) = world_from_body[N-1][:3, 3]
opos_target_frame_id(t) = N-1
```

这是用 LightNav 相机配置重新回放后记录的专家末帧地面坐标，保留其真实世界高度。
它不同于 R2R 元数据中的原始目标坐标，也不是相机中心、物体表面或识别框中心。
apos 表示随时间推进的局部目标；opos 表示固定的最终目的地。

1. 每帧用保存的 `world_from_camera_cv` 和 K 投影同一个三维终点。
2. 投影在画面内、camera-Z>0、深度有效且无遮挡时，保存精确 `pixel`、
   `pixel_rc`、48×27 `grid`、`world_point` 和空间 token，`loss_valid=true`。
3. 在视野外、相机后方或被有效深度遮挡时，标为 `not_visible`、`<opos_0>`，
   `loss_valid=true`，没有二维坐标或空间格子。
4. 投影处深度无效时为 `unknown`、`token_id=-1`、`loss_valid=false`。
5. **所有帧**均保存 `target_world_point` 和 `target_frame_id`，包括上述不可见和未知帧。
   opos 不沿路径回退到别处；只有 apos 使用可见路径回退。

采集器与离线补标默认都执行此规则。无需 API、识别框、语义资产或语义重渲染；
补标可直接使用 CPU。末帧终点在相机脚下时可能不在画面内，三维目标依然存在。
`object_binding.json` 保留兼容文件名，保存 `target_type=stop_location`、
`model_kind=recorded_terminal_ground_point`、固定坐标和末帧编号。
`opos_bound=true`、`object_bound=false` 表示终点已确定但没有绑定物体实例。
`episode.json` 中 `opos_search=null`，不生成 API 识别/搜索文件；
`manifest.json` 中 `api_requested=false`。

历史配置没有 `opos_mode` 时仍按旧版 `doubao` 解释，不重解释已有标签。
以下物体和末八帧搜索仅用于显式选择 `--opos-mode doubao` 的旧版流程。

## 可选旧版 opos：目标物体的实例绑定和跨帧可见性

实现：[doubao.py](../doubao.py)、[semantic_scene.py](../semantic_scene.py) 和
[annotate_r2r.py](../annotate_r2r.py)。

下面说明 `target_type=object` 的处理。候选选择及停止区域分支见下方“倒数八帧查找最终目标”。

1. 从末尾八帧按顺序向豆包发送**候选 RGB + 导航指令**，识别最终到达位置
   对应的物体或停止区域，返回类型、名称、归一化 bbox、内部点和置信度。
   仅沿途物体不算终点目标；没有可靠目标时允许 found=false，继续下一候选。
2. 检查返回结构、数值、坐标范围、框内点及置信度。畸形 JSON 或非归一化坐标
   会保存原始无效响应并要求模型修正；每张图与网络重试合计最多 3 次请求。
   不猜测坐标尺度，不自动除以 1000。重试耗尽、API 失败或输出截断会明确报错，
   不会伪造一个框，也不会转换为“目标不可见”。
3. 对物体目标，在保存的候选帧机体位姿处重渲染 Habitat semantic sensor。读取内部点对应的
   物体实例 ID，并要求至少 12 个实例像素落在框内、至少 60% 的可见实例像素
   被框包含。模糊匹配时继续下一候选，所有候选都失败才使该轨迹 opos 保持 unknown。
4. 从 MP3D 已有 `_semantic.ply` 中提取该 `object_id` 的所有三角形，转换为
   Habitat 世界坐标，保存独立网格、顶点颜色和三维包围范围。不会把 bbox 中的
   背景整体反投影成物体，也不向原始 Habitat 场景插入或改动物体。
5. 在每个已保存的机体位姿处渲染**同一个实例**。语义渲染提供遮挡后的可见区域；
   再要求当前 RGB 深度有效且反投影点位于该实例三维范围内，排除不同网格边缘
   不一致产生的背景点。在剩余可见像素中选择最接近区域中位位置的实际表面像素。
6. 实例在画面中没有渲染像素时标为 not_visible；有像素但太小、深度无效或与
   网格不一致时标为 unknown。所有末尾候选都无法可靠识别/绑定时，整条轨迹的 opos
   都是 unknown，不把未知身份标成不可见。

因此各帧的 opos 可以指向物体上不同的可见表面点，但绑定的物体实例保持一致。
三维模型覆盖该实例在源扫描中已有的表面，不补造扫描中缺失的物体背面。
当前要求场景有可用的 MP3D 语义实例，多个物体合并成同一实例等情况可能无法可靠绑定。

## 旧版语义回放的几何对齐要求

- semantic sensor 必须加载 MP3D `scene_dataset_config.json`；只加载 GLB 会产生
  语义轴向错位。不得删除此配置来绕过检查。
- 每帧重渲染深度与保存深度至少 99.5% 的有效像素须在 0.02 m + 1% 深度容差内。
- 当前支持的源 PLY 为 MP3D 三角网格，坐标转换为 `(x, z, -y)`；遇到其他布局报错。
- sensor 像素的值已经是物体 ID。`semantic_index_to_object_index()` 面向 HOUSE
  segment ID，不能再次用于 sensor 值。ID 0 与背景歧义，当前不绑定为目标。
- 语义 PLY 与 RGB GLB 的边缘可能不完全一致；不可靠表面点会被屏蔽，不扩大
  物体框来吸收这些像素。

## 可选旧版：倒数八帧查找最终目标

仅 `opos_mode=doubao` 的查找覆盖 `max(0,N-8)` 到 `N-1`，按时间顺序从前往后检查。
例如 52 帧的 episode 2864 检查 44、45、46、47、48、49、50、51，帧号从 0 开始。
少于八帧时从第 0 帧开始。`pointing_config.opos_search_frames` 默认 8；
读取未包含该字段的历史 metadata 时按原来的单末帧规则解释。

每个候选帧单独发送 RGB 和完整指令给豆包；没有识别到目标、置信度不足或
几何绑定失败时继续下一帧。找到首个可靠目标后停止 API 搜索，固定该目标，
再为整条 episode 逐帧生成 opos；不会在后续帧切换成别的相似物体。
API 失败不属于识别失败，仍会明确报错。

豆包返回 `target_type=object` 或 `stop_location`：

- `object`：沿用物体语义实例绑定和网格提取。除框/实例一致性外，还要求
  候选帧能产生有效可见表面点；绑定失败便继续下一候选帧。
- `stop_location`：识别的是指令要求的停止区域，例如“门内侧的地面”。
  以本管线保存的末帧 `world_from_body[:3,3]` 作为精确三维停止点，要求其
  在候选帧中位于豆包框内、投影在视野内且通过深度遮挡检查，才接受该区域。
  不把任意 bbox 中心或整片地板当作停止点。随后始终投影同一个三维停止点。

停止点在某帧视野外、相机后方或被有效深度遮挡时，该帧 `opos=0`、
`state=not_visible`；投影处深度无效时为 unknown。对八个候选都未能确认的
目标，整条 episode 仍为 unknown，而非不可见的负标签。

物体分支仍可能在同一实例上选择不同可见表面点；停止区域分支的世界坐标
固定。两者都输出原图像素、像素行列、48×27 网格、token 和独立有效 mask。
apos、RVQ 和 FM 的定义不受本次 opos 更新影响。

新增记录：`opos_search.json` 保存候选顺序、每次识别/绑定原因和选中帧；
`detections/<frame_id>.json/.png` 保存实际调用的候选结果和框预览；
`selected_detection.png` 展示选中帧。兼容文件 `doubao_detection.json` 增加
`source_frame_id`，它不再必然对应末帧。

`object_binding.json` 保留文件名，新增 `target_type`、`anchor_frame_id`；
停止点分支保存 `world_point`、`target_frame_id` 和
`model_kind=recorded_terminal_ground_point`，不生成物体网格或实例 masks。
episode 中 `opos_bound` 表示任一种目标已确认；`object_bound` 只表示物体实例
已绑定，停止区域分支为 false。`opos_target_type` 区分目标类型。

## 输出格式

轨迹级 `episode.json` 的逐字段解释和 2864 实例见 [EPISODE_FIELDS.md](EPISODE_FIELDS.md)。

新采集为 `beta_nav_v2`，默认采集结束即可得到 apos 和固定终点 opos。
已有 v1 数据也可直接补标，不需要重新采集 RGB/深度。

```text
NEW_POINTING_RUN/
  manifest.json                    源数据/代码哈希、参数、API 模型、场景配置
  summary.json                     全部选定轨迹处理完才生成
  failure.json                     失败时生成；不能据此当作整批完成
  provenance/                      管线代码、pointing 和语义配置快照；不包含 config.py
  episodes/<episode_id>/
    episode.json                   指令、相机、源路径/哈希、有效点数
    samples.jsonl                  干净的逐帧训练索引、RVQ 与 apos/opos token
    targets.npz                    RVQ/FM 数组及新增 pointing 数组
    doubao_detection.json          仅旧版模式：记录 API 返回，不含密钥
    opos_search.json               仅旧版模式：记录候选顺序和绑定结果
    detections/000044.json/.png     仅旧版模式：实际检查的候选和框预览
    selected_detection.png         仅旧版模式：选中候选的识别框预览
    object_binding.json            默认保存固定终点及来源；旧版可保存物体绑定
    object_model.npz               仅旧版模式且可靠绑定物体时生成
    object_masks/000000.npz         仅旧版模式且可靠绑定物体时生成
    preview_000000.png             首/中/末帧的点位预览，绿=apos、粉=opos
```

RGB/深度通过样本中的绝对路径引用原始采集，不重复复制。`targets.npz` 的 RVQ/FM
数组来自源数据，新增 `apos_pixel/opos_pixel` (N,2)、`apos_world/opos_world` (N,3)、
`apos_token_id/opos_token_id` (N,) 和 `apos_valid_mask/opos_valid_mask` (N,)。
新增 `apos_target_world` (N,3，float64，Habitat 世界坐标米) 和
`apos_target_frame_id` (N,)，保存投影/可见性筛选前的目标；最后十行都指向末帧。
即使 `apos_valid_mask=false`，这两个目标数组仍有真实值。
默认终点模式还保存 `opos_target_world` (N,3，float64) 和
`opos_target_frame_id` (N,，int32)，每行分别为相同的末帧坐标与 N-1。
这两个字段不受二维可见性影响；`opos_world` 仅在可见时有值。

有效点编码为 48×27 网格的 1..1296；opos 确认不可见为 0（有效监督）。未知为
-1（不发 token、mask=false），缺失坐标在数组中保存 NaN，在 JSON 中保存 null。
训练视觉历史只能读当前及过去 RGB；末尾识别结果、物体模型和未来位姿是监督侧信息。
目前不构建训练 prompt，也不会把完整轨迹最后一帧放进早期时刻的视觉输入。

## 二维像素与具体网格

从 2026-09-12 起，新采集/补标自动显式保存像素和网格索引。所有坐标以原始
470×280 RGB 为准，不包含视频的放大、顶部文字栏或侧边俯视图。

每帧的 `apos` / `opos` 中保存：

| 字段 | 含义 |
|---|---|
| `pixel` | 精确浮点像素 `[u,v]`，即 `[x,y]`，保持原值 |
| `pixel_rc` | 原图像素 `[row,col] = [floor(v),floor(u)]`，从 0 开始 |
| `grid.row` | 模型 48×27 网格中的行，范围 0～26 |
| `grid.col` | 网格中的列，范围 0～47 |
| `grid.cell_id` | 空间格子编号，`1 + row*48 + col`，范围 1～1296，与有效点 token_id 相同 |

网格换算为 `col=floor(u/width*48)`、`row=floor(v/height*27)`，边缘处理与
现有模型编码器保持一致。图像像素行列和模型网格行列是两种不同分辨率的索引。
`episode.json` 的 `pointing_grid` 保存原图尺寸、网格尺寸、索引顺序和缺失值约定。

真实例子：2864 的第 0 帧 apos 的像素为 `[250.2726976,257.7736847]`，
`pixel_rc=[257,250]`，网格 `row=24,col=25,cell_id=1178`，对应 `<apos_1178>`。
这里行列从 0 开始；按口语从 1 数，是第 25 行、第 26 列。

`targets.npz` 同时新增以下整型数组，apos/opos 各一组：

- `apos_pixel_rc` / `opos_pixel_rc`：`[N,2]`，原图整数像素行列。
- `apos_grid_rc` / `opos_grid_rc`：`[N,2]`，模型网格行列。
- `apos_grid_id` / `opos_grid_id`：`[N]`，空间格子编号。

没有有效空间点时，JSON 中 `pixel_rc` 和 `grid` 为 null，新增数组用 -1。
确认不可见的 opos 仍保留 token_id=0 及其有效分类监督，但 **没有空间格子**，
所以 grid_id=-1。缺失标签不会被塞进左上角或图像边缘的格子。

已保存的 pointing 数据可以离线补上这些字段，不调用 API、不重采集：

```bash
.venv/bin/python data_pipeline/export_pointing_grid.py \
  /mnt/cfs/data/beta_nav/r2r_2864_gt_20260911_v2 \
  --output-dir /mnt/cfs/data/beta_nav/r2r_2864_gt_grid_NEW \
  --episode-id 2864
```

参数 `dataset` 是已有 pointing 数据集根目录；`--output-dir` 必须是新目录；
`--episode-id` 可选，省略时处理输入中的全部 episode。
该入口还生成每条 episode 的 `pointing_pixels.csv`，便于直接查看每帧的像素和格子。
原始 RVQ/FM、像素、三维坐标、token、有效 mask 和豆包记录不变；
旧 provenance 保存在新输出的 `provenance/source_run`，源目录不会改写。

本次结果为 `/mnt/cfs/data/beta_nav/r2r_2864_gt_grid_20260912/episodes/2864`。

## 命令

默认 `opos_mode=terminal_ground`，CPU 即可完成 apos/opos 补标，不读取 API 配置，
不需要 Habitat、GPU 或语义资产。默认只处理 10 条，`--episodes -1` 才处理全部。

仅 `--opos-mode doubao` 读取本机 `data_pipeline/config.py` 中的 `LLM_DB_BASE_URL`、`LLM_DB_API_KEY` 和
`LLM_DB_MODEL`。该文件被 Git 忽略，也不会复制或哈希到 provenance；报告只保存
模型和 API 地址，不保存密钥。本机入口使用独立 Habitat Python 3.9。
模型/地址优先级为 CLI > `DOUBAO_MODEL`/`ARK_BASE_URL` > `LLM_DB_*` 环境变量 >
本地配置。密钥默认按 `ARK_API_KEY` > `LLM_DB_API_KEY` 环境变量 > 本地配置读取；
显式指定 `--api-key-env` 时只接受指定变量。提示词和指令前缀均为英文。

```bash
# CPU：只为 episode 2864 生成 apos 与最终目的地 opos；输出必须是新目录
.venv/bin/python data_pipeline/annotate_r2r.py \
  /mnt/cfs/data/beta_nav/r2r_train_470x280_20260911 \
  --output-dir /mnt/cfs/data/beta_nav/r2r_pointing_NEW_RUN \
  --episode-id 2864 --episodes 1

# 只核对输入，不调用 API、不渲染、不写文件
.venv/bin/python data_pipeline/annotate_r2r.py DATASET --output-dir NEW_OUTPUT --dry-run

# 可选旧版：用豆包识别末八帧目标，物体模式需要 Habitat 语义资产
bash data_pipeline/annotate.sh DATASET --output-dir NEW_DOUBAO_OUTPUT --opos-mode doubao

# 明确只生成 apos；不调用 API、不使用 GPU，opos 保持 unknown
.venv/bin/python data_pipeline/annotate_r2r.py DATASET \
  --output-dir NEW_APOS_OUTPUT --apos-only

# 检查源数据哈希、帧对齐、坐标投影、可见 mask 和 token
.venv/bin/python data_pipeline/validate_r2r.py NEW_OUTPUT
```

仅豆包模式中，每条轨迹按顺序调用 API，最多检查八张不同候选图；找到可靠三维目标即停止。
429/部分 5xx/网络错误及输出格式修正共用每张候选图最多 3 次请求的预算。
无效格式的原始响应保存在 `detections/<frame_id>.invalid_<time>.json`；
成功记录的 `request_attempt` 和 `invalid_response_files` 保留重试来源。
单次网络超时为 120 秒，包含 Python 3.9 的 socket 超时处理。请求明确关闭 thinking，
使用最多 2048 个输出 token 的 JSON 模式；这些选项也保存到请求身份/缓存哈希中。
默认只处理 10 条，`--episodes -1` 才处理全部。

| 参数 | 默认 | 含义 |
|---|---|---|
| `dataset` | 必填 | 原始完整采集目录 |
| `--output-dir` | 必填 | 新的补标目录，拒绝覆盖 |
| `--config` | `data_pipeline/configs/pointing.json` | 几何和绑定阈值 |
| `--opos-mode` | JSON 中的 `terminal_ground` | `terminal_ground` 固定专家终点；`doubao` 为旧版物体/停止区域识别 |
| `--episodes` | 10 | 处理数量，-1 为全部 |
| `--episode-id` | 无 | 仅处理指定 episode |
| `--apos-only` | 关闭 | 明确只做 apos，opos unknown |
| `--doubao-model` | 环境变量或 `config.py` 的 `LLM_DB_MODEL` | 视觉模型名/Endpoint ID，不擅自替换模型 |
| `--api-key-env` | 未显式指定时按上述优先级读取 | 指定后只读取此环境变量，缺失时报错 |
| `--api-base-url` | 环境变量或 `config.py`，最后回退北京 Ark v3 地址 | HTTPS API 地址 |
| `--detection-cache-dir` | 无 | 按图片/指令/提示词/模型/API地址哈希复用响应；仍需配置凭证 |
| `--scenes-dir` | `BETA_SCENES_DIR` 或本机场景目录 | MP3D 场景根目录 |
| `--scene-dataset-config` | 场景根目录下 `mp3d/mp3d.scene_dataset_config.json` | 语义渲染坐标配置 |
| `--gpu-id` | `BETA_GPU_ID` 或 3 | 渲染 GPU |
| `--dry-run` | 关闭 | 仅检查输入和输出配置，不验证在线 API 权限 |

API、缓存、场景和 GPU 参数仅豆包模式使用。
`annotate.sh` 同时支持 `HABITAT_PYTHON`，含义与采集入口相同。
原采集入口新增 `--pointing-config`，默认同一份 JSON；horizon 固定为 10。
其余阈值在 [pointing.json](../configs/pointing.json) 中记录，改动后生成新的数据版本。

## 接口依据与验证范围

API 消息采用官方 SDK 的 [image_url 定义](https://github.com/volcengine/volcengine-python-sdk/blob/master/volcenginesdkarkruntime/types/chat/chat_completion_content_part_image_param.py)
和 [Chat Completions/JSON 模式定义](https://github.com/volcengine/volcengine-python-sdk/blob/master/volcenginesdkarkruntime/types/chat/completion_create_params.py)。
语义配置依据 Habitat 官方 [sensor 测试](https://github.com/facebookresearch/habitat-sim/blob/main/tests/test_sensors.py)。
具体账号、视觉模型支持及框选质量仍需真实 API 调用验证。

离线测试中的合成 API 响应只验证接口契约；手动选择场景实例的实景几何探针只验证
网格提取/逐帧可见性，不能当作豆包识别成功或实际语义标注数据。
