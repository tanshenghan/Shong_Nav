# R2R expert collection for beta_nav

Current format is `beta_nav_v2`: the collector exports min(t+10, N-1) ground-point apos
and fixed final-destination opos, and no longer exports forward/left/right labels
in frames or samples. Default `opos_mode=terminal_ground` requires no API or semantic
assets. Legacy Doubao + MP3D object annotation is optional. See
[POINTING.md](POINTING.md) for current definitions, arrays, parameters and commands.
Historical v1 collections retain their original format and can be annotated in a new overlay.

This collector replays R2R expert actions through Habitat-Sim with camera and
motion settings from `habitat_server/configs/vlnce_r2r.yaml`. It records new RGB,
metric depth, body poses and sensor poses. R2R supplies only the instruction,
scene, initial state and reference route/actions. No InternData RGB, depth, pose
or camera calibration is used, and no LightNav neural inference is performed.

The first dataset uses 470 × 280 pixels (width × height), horizontal FOV 120°,
camera position `[0, 0.88, 0]` in Habitat body coordinates, and zero camera pitch.
These are native rendered dimensions, not a resized visualization. The later
model input processor may resize images according to its checkpoint settings.

## Run

Use a separate Python 3.9 Habitat-Sim environment with numpy, numpy-quaternion,
Pillow and PyYAML. Do not install Habitat into the inference `.venv`. The collector
uses native Habitat-Sim, so it does not need Habitat-Lab task registrations or a
running ZMQ/WebSocket server. A rendering GPU and existing MP3D assets are needed.

```bash
python data_pipeline/collect_r2r.py \
  --config habitat_server/configs/vlnce_r2r.yaml \
  --data-root /mnt/cfs/data/habitat/datasets/R2R_VLNCE_v1-3_preprocessed \
  --scenes-dir /mnt/cfs/data/habitat/scene_datasets \
  --rvq-bundle /mnt/cfs/Models/Light/action_tokenizer \
  --output-dir /mnt/cfs/data/beta_nav/r2r_train_470x280_NEW_RUN \
  --width 470 --height 280 --episodes 10 --seed 20260911 --gpu-id 3
```

Add `--dry-run` to validate source files and inspect calibration without rendering
or writing. Each output directory must be new; the script never overwrites a run.
`--episodes -1` selects all unique physical training routes, with one instruction
per scene/trajectory pair. It does not duplicate rendering for the alternative
R2R instructions on the same route. A seeded shuffle chooses routes and the
result is sorted by scene to reduce scene loading. Only `train` is accepted.

For headless EGL settings, see [HABITAT_SERVER.md](../../docs/HABITAT_SERVER.md). The renderer
uses the existing MP3D `.navmesh` files without changing source assets. The runtime
version is saved in the manifest. The available Habitat-Sim 0.2.4 runtime crashed
during GPU initialization on this machine; native Habitat-Sim 0.3.3 passed a render
probe. Matching the camera settings does not imply an identical simulator binary
to the published evaluation environment.

## Files and coordinate conventions

```text
run/
  manifest.json              source/codebook hashes, sampling and camera conventions
  resolved_simulator.json    LightNav simulator parameters actually used
  progress.json              number of completed episodes
  summary.json               written only when the entire requested run succeeds
  episodes/<episode_id>/
    episode.json             instruction, calibration, source route, quality checks
    frames.jsonl             per-frame paths and real body/camera poses; no action-class labels
    rgb/000000.png           uint8 RGB, 470 × 280
    depth/000000.npz         float32 depth_m and boolean valid, both 280 × 470
    targets.npz              RVQ-10, continuous FM-30, apos-10 and independent masks
    samples.jsonl            sample indices and action tokens
```

Only episodes with `complete: true` in `episode.json` are usable. A caught failure
writes `failure.json`; a native crash may leave only incomplete files. Neither
case creates a successful `summary.json`.

Body poses are `world_from_body` in Habitat's native coordinates: world +Y is up,
body +X is right, +Y up and -Z forward. Camera poses are
`world_from_camera_cv` and `world_from_depth_camera_cv`, using OpenCV camera axes:
+X right, +Y down, +Z forward. Sensor poses are measured from the simulator after
each step, including the real camera-to-body offset. RGB and depth are co-located
and their poses and calibration are checked for agreement.

Depth is camera-Z in metres, clipped to the configured 0–10 m sensor range, with
normalization disabled. Zero / clipped-far values are invalid in the stored
`valid` mask. Always use that mask for later geometry. K is stored in both the
manifest and episode calibration; pixels use an image-edge coordinate convention
with centre `(W/2, H/2)`. At 470 × 280 and 120° HFOV, fx = fy ≈ 135.6773 pixels.

## Action supervision

The observation at frame `t` is saved **before** the internal expert action at `t` executes.
The next pose is measured after that action. Turns are real orientation changes,
including stationary turns; heading is never inferred from XY path tangents.

`targets.npz` contains:

| Array | Shape | Meaning |
|---|---|---|
| `world_from_body` | N × 4 × 4 | fresh measured body transforms |
| `world_from_camera_cv` | N × 4 × 4 | fresh measured RGB camera transforms |
| `world_from_depth_camera_cv` | N × 4 × 4 | fresh measured depth camera transforms |
| `fm_waypoints_ego` | N × 30 × 3 | future poses expressed in current body frame |
| `fm_clean_se2_diff` | N × 30 × 3 | each future movement relative to the preceding pose |
| `fm_valid_mask` | N × 30 | whether that future pose was actually observed |
| `future_frame_ids` | N × 30 | source frame indices; -1 for unknown future |
| `future_vertical_offset_m` | N × 30 | world-height changes omitted from planar SE(2) |
| `rvq_codes` | N × 3 | three fixed-codebook indices; -1 for missing chunks |
| `rvq_valid_mask` | N | whether the entire token chunk may supervise CE |
| `rvq_reconstruction` | N × 10 × 3 | decoded trajectory, for diagnostics |
| `rvq_ade_m` | N | quantization error; NaN when no full motion chunk exists |

Trajectory components are forward metres, left metres, and CCW yaw radians.
The first 10 future steps are shared by RVQ and FM. FM labels use actual measured
poses **before** quantization, not RVQ reconstruction. The 30 FM positions are
future environment steps, not 30 flow-integration iterations. Noise and flow time
should be sampled dynamically during training; stored clean values are not yet
normalized using training-set statistics.

RVQ uses the released 10-step, 3 × 256, weighted-SE(2)-difference bundle. Its new
encoder searches greedily over residual levels with integrated ADE plus 0.3 times
wrapped endpoint heading error. This is not a claim of bit-identical reproduction
of the unpublished official training encoder. The reserved STOP L0 code is never
used for motion; the full STOP tuple supervises only the final explicit expert
STOP after verifying goal distance < 3 m.

Unknown tail steps are masked. Repeated final poses in array padding are storage
values only. Partial RVQ chunks are masked as a whole; partial FM chunks retain
their observed steps. The terminal observation has no FM future supervision.
The collector now emits both geometric apos and final-destination opos labels.
With default `opos_mode=terminal_ground`, `opos_target_world` is the recorded final
body ground position repeated at every frame, and `opos_target_frame_id` is N-1.
`opos_world`/`opos_pixel` exist only where this exact point is visible; no fallback
point is used. Proven invisibility has token 0 and a valid classification mask;
invalid depth yields unknown/masked supervision. All frames retain the 3D target.
Only legacy `opos_mode=doubao` leaves collection opos pending for a separate
object/stop-region annotator.
No turn/STOP apos directives are emitted. Unknown pointing targets are masked.
With `tail_policy=terminal`, `apos_target_world` and `apos_target_frame_id` retain
the intended 3D ground target independently of pixel visibility; the last ten
frames all target the recorded terminal position. `apos_world` is the selected
visible point, possibly after path backtracking. RVQ/FM tail masks are unchanged.

These are discrete expert transitions (0.25 m forward / 15° turns in the current
LightNav YAML). `physical_dt_s` is null: the velocity-control action's configured
0.1 s interval does not apply to this discrete replay. RGB viewing FPS should not
be interpreted as a measured physical control period.

For training, history may contain only frames up to the sample's `frame_id`.
Future poses and RVQ GT are supervision, not visual-conditioning features. Loss
masks do not prevent attention from reading a teacher-forced answer. Treat
scene/trajectory IDs as split groups when adding new instructions or camera views.

## Collection command parameters

| Flag | Default | Meaning |
|---|---|---|
| `--output-dir` | required | New output directory; existing directories are rejected |
| `--data-root` | required | R2R-VLNCE root containing `train/train{,_gt}.json.gz` |
| `--scenes-dir` | required | Scene root containing `mp3d/<scene>/<scene>.glb` and `.navmesh` |
| `--rvq-bundle` | required | Released 10-step `action_tokenizer` bundle |
| `--config` | `habitat_server/configs/vlnce_r2r.yaml` | LightNav simulator/camera configuration |
| `--split` | `train` | Only the training split is accepted |
| `--episodes` | `10` | Unique routes; `-1` means all unique training routes |
| `--seed` | `20260911` | Deterministic route selection and simulation seed |
| `--gpu-id` | `0` | Habitat-Sim rendering device |
| `--width` | `470` | Rendered RGB/depth width |
| `--height` | `280` | Rendered RGB/depth height |
| `--pointing-config` | `data_pipeline/configs/pointing.json` | apos geometry and visibility settings |
| `--dry-run` | false | Validate inputs and print manifest without rendering or writing |

## Validation command

```bash
.venv/bin/python data_pipeline/validate_r2r.py \
  /mnt/cfs/data/beta_nav/r2r_train_470x280_20260911
```

The required positional argument is the dataset run directory. The command prints
its report without modifying the dataset; optional `--report PATH` also saves it
to a new JSON file (an existing report is never overwritten). This validator
checks the current 470 × 280, 120° HFOV, 0.88 m, zero-pitch, RVQ-10/FM-30 paradigm.
Update its assumptions explicitly when introducing a different collection schema.
