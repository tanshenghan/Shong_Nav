"""Chronological destination search, endpoint grounding and historical compatibility."""

import json

import numpy as np
import pytest
from PIL import Image

from data_pipeline.annotate_r2r import annotate_episode
from data_pipeline.collect_r2r import sha256
from data_pipeline.destination import tail_frame_ids
from data_pipeline.doubao import validate_detection
from data_pipeline.pointing import PointingConfig, bind_stop_location, fixed_world_point
from data_pipeline.validate_pointing import validate_pointing


def make_source(tmp_path, *, moving=True):
    source = tmp_path / "source" / "episodes" / "test"
    source.mkdir(parents=True)
    (source.parents[1] / "manifest.json").write_text("{}")
    frames = []
    K = np.array([[50., 0, 50.], [0, 50., 50.], [0, 0, 1.]])
    for i in range(12):
        body = np.eye(4)
        body[2, 3] = -i * .25 if moving else 0.
        camera = body @ np.diag([1., -1., -1., 1.])
        camera[1, 3] = .88
        Image.new("RGB", (100, 100)).save(source / f"{i}.png")
        np.savez(source / f"{i}.npz", depth_m=np.full((100, 100), 2.), valid=np.ones((100, 100), bool))
        frames.append(dict(frame_id=i, rgb=f"{i}.png", depth=f"{i}.npz",
                           world_from_body=body.tolist(), world_from_camera_cv=camera.tolist()))
    (source / "frames.jsonl").write_text("\n".join(json.dumps(f) for f in frames))
    (source / "samples.jsonl").write_text("\n".join(json.dumps(dict(frame_id=i, history_end_inclusive=i))
                                                       for i in range(12)))
    (source / "episode.json").write_text(json.dumps(dict(complete=True, frames=12, episode_id="test",
        scene_id="synthetic", instruction="Stop just inside the doorway.",
        camera=dict(width=100, height=100, K=K.tolist()))))
    np.savez(source / "targets.npz", fm_clean_se2_diff=np.zeros((12, 30, 3)))
    return source, frames, K


def stop_detection(box=None):
    return dict(found=True, target_type="stop_location", label="floor just inside the doorway",
                bbox_xyxy=box or [.3, .5, .8, .95], point_xy=[.5, .7], confidence=.9,
                reason="visible destination floor")


def test_tail_search_indices_and_legacy_config():
    assert tail_frame_ids(52) == list(range(44, 52))
    assert tail_frame_ids(3) == [0, 1, 2]
    assert PointingConfig.from_metadata({}).opos_search_frames == 1
    assert PointingConfig.from_metadata({}).opos_mode == "doubao"
    assert PointingConfig().opos_search_frames == 8
    assert PointingConfig().opos_mode == "terminal_ground"
    with pytest.raises(ValueError):
        PointingConfig(opos_search_frames=0)


def test_stop_region_requires_endpoint_inside_and_visible(tmp_path):
    _, frames, K = make_source(tmp_path)
    cfg = PointingConfig()
    goal = np.asarray(frames[-1]["world_from_body"])[:3, 3]
    depth, valid = np.full((100, 100), 2.), np.ones((100, 100), bool)
    assert bind_stop_location(stop_detection(), goal, frames[4], K, depth, valid, cfg)["bound"]
    bad_region = stop_detection([.1, .1, .2, .2])
    assert not bind_stop_location(bad_region, goal, frames[4], K, depth, valid, cfg)["bound"]
    assert not bind_stop_location(stop_detection(), goal, frames[4], K, depth * .1, valid, cfg)["bound"]
    assert not bind_stop_location(stop_detection(), goal, frames[-1], K, depth, valid, cfg)["bound"]
    unknown = fixed_world_point(goal, frames[4]["world_from_camera_cv"], K, depth, valid & False, cfg)
    assert unknown["state"] == "unknown" and not unknown["loss_valid"]
    occluded = fixed_world_point(goal, frames[4]["world_from_camera_cv"], K, depth * .1, valid, cfg)
    assert occluded["state"] == "not_visible" and occluded["token_id"] == 0


def test_search_continues_after_miss_and_bad_binding_then_freezes_target(tmp_path):
    source, _, _ = make_source(tmp_path)
    calls = []

    class Grounder:
        def identify(self, image, instruction, cache):
            frame = int(image.stem)
            calls.append(frame)
            detection = stop_detection()
            if frame == 4:
                detection = dict(found=False, confidence=0., reason="not visible")
            if frame == 5:
                detection = stop_detection([.3, .1, .8, .4])
                detection["point_xy"] = [.5, .2]
            return {"detection": detection}

    root = tmp_path / "labels"
    folder = root / "episodes" / "test"
    result = annotate_episode(source, folder, PointingConfig(opos_mode="doubao"), grounder=Grounder())
    assert calls == [4, 5, 6]
    assert result["opos_bound"] and not result["object_bound"]
    assert result["opos_target_type"] == "stop_location"
    assert result["opos_search"]["selected_frame_id"] == 6
    assert result["opos_visible"] > 0
    assert not (folder / "object_masks").exists()
    rows = [json.loads(s) for s in (folder / "samples.jsonl").read_text().splitlines()]
    assert rows[-1]["opos"]["state"] == "not_visible"
    points = [r["opos"]["world_point"] for r in rows if r["opos"]["state"] == "point"]
    assert all(p == [0., 0., -2.75] for p in points)
    (root / "manifest.json").write_text(json.dumps(dict(source_dataset=str(source.parents[1]),
        source_manifest_sha256=sha256(source.parents[1] / "manifest.json"),
        pointing_config=PointingConfig(opos_mode="doubao").metadata(), episodes=["test"])))
    assert validate_pointing(root)["opos_visible"] == result["opos_visible"]


def test_all_misses_stay_unknown_instead_of_negative_labels(tmp_path):
    source, _, _ = make_source(tmp_path)
    calls = []

    class Grounder:
        def identify(self, image, instruction, cache):
            calls.append(int(image.stem))
            return dict(detection=dict(found=False, confidence=0., reason="not identifiable"))

    folder = tmp_path / "labels"
    result = annotate_episode(source, folder, PointingConfig(opos_mode="doubao"), grounder=Grounder())
    assert calls == list(range(4, 12))
    assert not result["opos_bound"] and result["opos_valid"] == 0
    with np.load(folder / "targets.npz") as targets:
        assert (targets["opos_token_id"] == -1).all()


def test_nonterminal_object_anchor_reuses_the_correct_semantic_frame(tmp_path, monkeypatch):
    source, _, _ = make_source(tmp_path, moving=False)
    mesh = tmp_path / "semantic.ply"
    mesh.write_bytes(b"synthetic mesh supplied by fixture")
    monkeypatch.setattr("data_pipeline.semantic_scene.extract_object_mesh", lambda *a: dict(
        aabb_world=np.array([[0., 0., -2.1], [1., 1., -1.9]]), world_from_mp3d=np.eye(4)))

    class Grounder:
        def identify(self, image, instruction, cache):
            return dict(detection=dict(found=True, label="door frame", target_type="object",
                        bbox_xyxy=[.5, .5, .8, .8], point_xy=[.6, .6], confidence=.9, reason="target"))

    class Replay:
        semantic_mesh = mesh
        objects = {7: dict(category="door")}

        def __init__(self):
            self.frames = []

        def observe(self, frame, depth, valid):
            self.frames.append(frame["frame_id"])
            semantic = np.zeros((100, 100), np.int32)
            semantic[55:70, 55:70] = 7
            return semantic, 1.

    replay = Replay()
    result = annotate_episode(source, tmp_path / "labels", PointingConfig(opos_mode="doubao"),
                              grounder=Grounder(), replay=replay)
    assert result["object_bound"] and result["opos_visible"] == 12
    assert result["opos_search"]["selected_frame_id"] == 4
    assert replay.frames == [4, 0, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11]


def test_stop_type_validation_and_object_only_legacy_schema():
    assert validate_detection(stop_detection())["target_type"] == "stop_location"
    old = stop_detection()
    old.pop("target_type")
    assert "target_type" not in validate_detection(old)
    with pytest.raises(ValueError, match="target_type"):
        validate_detection({**stop_detection(), "target_type": "room"})


def test_default_opos_tracks_final_destination_without_grounder(tmp_path):
    source, _, _ = make_source(tmp_path)

    class ForbiddenGrounder:
        def identify(self, *args):
            pytest.fail("terminal destination does not require visual recognition")

    folder = tmp_path / "labels"
    result = annotate_episode(source, folder, PointingConfig(), grounder=ForbiddenGrounder())
    assert result["opos_bound"] and result["opos_search"] is None
    assert not result["object_bound"] and result["opos_visible"] > 0
    assert not (folder / "detections").exists()
    rows = [json.loads(s) for s in (folder / "samples.jsonl").read_text().splitlines()]
    assert all(r["opos"]["target_world_point"] == [0., 0., -2.75] for r in rows)
    assert all(r["opos"]["target_frame_id"] == 11 for r in rows)
    assert rows[0]["apos"]["target_frame_id"] == 10
    assert rows[0]["opos"]["state"] == "not_visible"  # occluded by depth at 2 m
    assert rows[-1]["opos"]["state"] == "not_visible"  # beneath the terminal camera
    assert rows[-1]["opos"]["pixel"] is None
    with np.load(folder / "targets.npz") as data:
        np.testing.assert_array_equal(data["opos_target_frame_id"], np.full(12, 11))
        np.testing.assert_array_equal(data["opos_target_world"], np.tile([0., 0., -2.75], (12, 1)))


def test_default_annotation_cli_needs_neither_api_config_nor_semantic_assets(tmp_path, monkeypatch):
    import data_pipeline.annotate_r2r as annotate

    source, _, _ = make_source(tmp_path)
    output = tmp_path / "default_run"

    def forbidden(*args, **kwargs):
        pytest.fail("default annotation must not read API credentials or construct a grounder")

    monkeypatch.setattr(annotate, "load_api_settings", forbidden)
    monkeypatch.setattr(annotate, "DoubaoGrounder", forbidden)
    monkeypatch.setattr("sys.argv", ["annotate_r2r.py", str(source.parents[1]),
                        "--output-dir", str(output), "--scenes-dir", str(tmp_path / "missing_scenes"),
                        "--scene-dataset-config", str(tmp_path / "missing_semantics.json")])
    annotate.main()
    report = json.loads((output / "manifest.json").read_text())
    assert report["opos_mode"] == "terminal_ground" and not report["api_requested"]
    assert report["api_base_url"] is None and report["scene_dataset_config"] is None
    assert validate_pointing(output)["opos_visible"] > 0
