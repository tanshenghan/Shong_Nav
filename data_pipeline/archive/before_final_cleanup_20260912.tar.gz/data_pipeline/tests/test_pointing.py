"""Pointing semantics, occlusion, API validation and mesh/instance correspondence."""

import io
import json
import shutil
import socket
import urllib.error

import numpy as np
import pytest
from PIL import Image

from data_pipeline.annotate_r2r import annotate_episode, provenance_code_paths
from data_pipeline.collect_r2r import export_targets, sha256
from data_pipeline.doubao import PROMPT, DoubaoGrounder, load_api_settings, validate_detection
from data_pipeline.export_pointing_grid import export_grid
from data_pipeline.pointing import (
    PointingConfig,
    backproject_pixels,
    bind_instance,
    ground_point,
    object_point,
    project_world,
)
from data_pipeline.semantic_scene import extract_object_mesh
from data_pipeline.validate_pointing import validate_pointing
from lightnav.traj_vocab import RVQBundle


@pytest.fixture
def camera():
    pose = np.diag([1., -1., -1., 1.])
    pose[1, 3] = .88
    return pose, np.array([[50., 0., 50.], [0., 50., 50.], [0., 0., 1.]])


def trajectory(n=20):
    p = np.zeros((n, 3))
    p[:, 2] = -np.arange(n) * .25
    return p


def detection():
    return dict(found=True, label="chair", bbox_xyxy=[.2, .2, .8, .8],
                point_xy=[.45, .5], confidence=.95, reason="terminal landmark")


def test_apos_exact_ten_ground_point_and_height(camera):
    pose, K = camera
    p = ground_point(trajectory(), 0, pose, K, np.full((100, 100), 9.),
                     np.ones((100, 100), bool), PointingConfig())
    assert p["reason"] == "t_plus_10"
    assert p["world_point"] == [0., 0., -2.5]
    assert p["pixel"] == pytest.approx([50., 67.6])
    assert p["backtrack_m"] == 0


def test_apos_depth_occlusion_backtracks_to_closest_visible_on_path(camera):
    pose, K = camera
    cfg = PointingConfig(depth_tolerance_m=0., depth_relative_tolerance=0.)
    p = ground_point(trajectory(), 0, pose, K, np.full((100, 100), 1.8),
                     np.ones((100, 100), bool), cfg)
    assert p["reason"] == "visible_path_backtrack"
    assert 1.8 - cfg.path_spacing_m <= -p["world_point"][2] <= 1.8
    assert p["selected_frame_fraction"] < 10
    assert p["backtrack_m"] == pytest.approx(2.5 + p["world_point"][2])


@pytest.mark.parametrize("mode", ["invalid_depth", "behind_camera", "stationary"])
def test_apos_unknown_never_creates_turn_stop_or_edge_token(camera, mode):
    pose, K = camera
    points, valid, t = trajectory(), np.ones((100, 100), bool), 0
    if mode == "invalid_depth":
        valid[:] = False
    elif mode == "behind_camera":
        points[:, 2] *= -1
    elif mode == "stationary":
        points[:] = 0
    p = ground_point(points, t, pose, K, np.full((100, 100), 9.), valid, PointingConfig())
    assert p["token_id"] == -1 and not p["loss_valid"] and p["pixel"] is None


@pytest.mark.parametrize("n,t", [(20, 10), (20, 19), (5, 0), (1, 0)])
def test_apos_tail_keeps_terminal_world_target_even_without_a_pixel(camera, n, t):
    pose, K = camera
    positions = trajectory(n)
    pose[:3, 3] += positions[t]
    p = ground_point(positions, t, pose, K, np.full((100, 100), 9.),
                     np.ones((100, 100), bool), PointingConfig())
    assert p["target_frame_id"] == n - 1
    assert p["target_world_point"] == positions[-1].tolist()
    if t == n - 1:
        assert p["world_point"] is None and p["pixel"] is None
        assert not p["loss_valid"]
    else:
        assert p["world_point"] == positions[-1].tolist()
        assert p["reason"] == "terminal_ground_point" and p["loss_valid"]


def test_apos_tail_occlusion_still_uses_visible_path_backtrack(camera):
    pose, K = camera
    positions = trajectory()
    pose[:3, 3] += positions[10]
    p = ground_point(positions, 10, pose, K, np.full((100, 100), 1.8),
                     np.ones((100, 100), bool), PointingConfig())
    assert p["reason"] == "visible_path_backtrack"
    assert p["target_world_point"] == positions[-1].tolist()
    assert p["world_point"] != p["target_world_point"] and p["loss_valid"]


def test_historical_pointing_metadata_preserves_masked_tail(camera):
    pose, K = camera
    cfg = PointingConfig.from_metadata({"horizon": 10})
    p = ground_point(trajectory(), 10, pose, K, np.full((100, 100), 9.),
                     np.ones((100, 100), bool), cfg)
    assert p["reason"] == "missing_t_plus_10" and not p["loss_valid"]
    assert "target_world_point" not in p


def test_projection_roundtrip_and_world_rotation(camera):
    pose, K = camera
    angle = .7
    transform = np.eye(4)
    transform[:3, :3] = [[np.cos(angle), 0, np.sin(angle)], [0, 1, 0],
                         [-np.sin(angle), 0, np.cos(angle)]]
    transform[:3, 3] = [3, 7, 11]
    pose = transform @ pose
    pixels = np.array([[14.5, 77.5], [61.5, 36.5]])
    points = backproject_pixels(pixels, [2., 4.], pose, K)
    uv, z = project_world(points, pose, K)
    np.testing.assert_allclose(uv, pixels, atol=1e-10)
    np.testing.assert_allclose(z, [2, 4])


def test_bind_exact_instance_and_reject_background_oversized_instance():
    semantic = np.zeros((10, 10), int)
    semantic[2:8, 2:8] = 7
    assert bind_instance(detection(), semantic, {7: {}}, PointingConfig())["semantic_id"] == 7
    semantic[:] = 7
    assert not bind_instance(detection(), semantic, {7: {}}, PointingConfig())["bound"]
    semantic[:] = 0
    assert not bind_instance(detection(), semantic, {0: {}}, PointingConfig())["bound"]


def test_opos_visible_surface_not_box_center_and_visibility_states(camera):
    pose, K = camera
    semantic = np.zeros((100, 100), int)
    semantic[20:80, 20:80] = 7
    semantic[40:60, 40:60] = 0  # chair/handle hole must not become the point
    depth, valid = np.full((100, 100), 2.), np.ones((100, 100), bool)
    p = object_point(semantic, 7, depth, valid, pose, K, PointingConfig())
    col, row = np.floor(p["pixel"]).astype(int)
    assert semantic[row, col] == 7 and p["loss_valid"]
    p = object_point(semantic, 8, depth, valid, pose, K, PointingConfig())
    assert p["state"] == "not_visible" and p["token_id"] == 0 and p["loss_valid"]
    p = object_point(semantic, 7, depth, valid & False, pose, K, PointingConfig())
    assert p["state"] == "unknown" and p["token_id"] == -1 and not p["loss_valid"]


def test_opos_semantic_edge_on_unrelated_depth_is_masked(camera):
    pose, K = camera
    semantic = np.full((100, 100), 7)
    # The rendered instance is at 2m; a depth surface at 5m is unrelated background.
    point = object_point(semantic, 7, np.full((100, 100), 5.),
                         np.ones((100, 100), bool), pose, K, PointingConfig(),
                         world_bounds=[[-1, -1, -2.1], [1, 2, -1.9]])
    assert point["reason"] == "instance_depth_outside_mesh"
    assert not point["loss_valid"] and point["token_id"] == -1


@pytest.mark.parametrize("update", [
    {"found": "true"}, {"confidence": float("nan")}, {"confidence": True},
    {"bbox_xyxy": [20, 20, 80, 80]}, {"point_xy": [.9, .5]},
    {"point_xy": [1., .5]}, {"bbox_xyxy": [.8, .2, .2, .8]}, {"label": ""},
])
def test_doubao_rejects_unusable_grounding(update):
    with pytest.raises(ValueError):
        validate_detection({**detection(), **update})


def test_doubao_request_is_cached_without_credentials(tmp_path, monkeypatch):
    monkeypatch.setenv("TEST_ARK_KEY", "fake-secret-never-save")
    image = tmp_path / "final.png"
    Image.new("RGB", (10, 10)).save(image)
    cache = tmp_path / "cache.json"
    calls = []

    class Opener:
        def open(self, req, timeout):
            calls.append(req)
            body = json.loads(req.data)
            assert body["model"] == "test-vision-endpoint"
            assert body["thinking"] == {"type": "disabled"}
            assert body["messages"][0]["content"] == PROMPT and PROMPT.isascii()
            assert body["messages"][1]["content"][0]["text"] == "Navigation instruction: go to chair"
            assert body["messages"][1]["content"][1]["image_url"]["url"].startswith("data:image/png;base64,")
            assert req.get_header("Authorization") == "Bearer fake-secret-never-save"
            return io.BytesIO(json.dumps({"choices": [{"finish_reason": "stop",
                "message": {"content": json.dumps(detection())}}], "id": "test-call"}).encode())

    monkeypatch.setattr("urllib.request.build_opener", lambda *args: Opener())
    client = DoubaoGrounder("test-vision-endpoint", key_env="TEST_ARK_KEY")
    a = client.identify(image, "go to chair", cache)
    assert client.identify(image, "go to chair", cache) == a
    assert len(calls) == 1 and "fake-secret" not in cache.read_text()
    with pytest.raises(ValueError, match="identity mismatch"):
        client.identify(image, "different target", cache)


def test_api_failure_does_not_become_not_visible_or_leak_secret(tmp_path, monkeypatch):
    monkeypatch.setenv("TEST_ARK_KEY", "fake-secret")
    image = tmp_path / "final.png"
    Image.new("RGB", (10, 10)).save(image)

    class Opener:
        def open(self, req, timeout):
            raise urllib.error.HTTPError(req.full_url, 401, "fake-secret", {}, io.BytesIO(b"fake-secret"))

    monkeypatch.setattr("urllib.request.build_opener", lambda *args: Opener())
    with pytest.raises(RuntimeError, match="HTTP 401") as error:
        DoubaoGrounder("test", key_env="TEST_ARK_KEY").identify(image, "goal", tmp_path / "cache.json")
    assert "fake-secret" not in str(error.value)
    assert not (tmp_path / "cache.json").exists()


@pytest.mark.parametrize("recover", [True, False])
def test_bad_coordinate_response_is_recorded_and_retried_not_rescaled(tmp_path, monkeypatch, recover):
    image = tmp_path / "candidate.png"
    Image.new("RGB", (10, 10)).save(image)
    calls = []

    class Opener:
        def open(self, req, timeout):
            calls.append(json.loads(req.data))
            value = detection()
            if not recover or len(calls) == 1:
                value.update(bbox_xyxy=[200, 200, 800, 800], point_xy=[450, 500])
            return io.BytesIO(json.dumps({"choices": [{"finish_reason": "stop",
                "message": {"content": json.dumps(value)}}]}).encode())

    monkeypatch.setattr("urllib.request.build_opener", lambda *args: Opener())
    client = DoubaoGrounder("test", api_key="fake-secret")
    cache = tmp_path / "response.json"
    if recover:
        result = client.identify(image, "go to chair", cache)
        assert result["detection"] == detection()
        assert result["request_attempt"] == 2 and len(result["invalid_response_files"]) == 1
    else:
        with pytest.raises(ValueError, match="format invalid after retries"):
            client.identify(image, "go to chair", cache)
        assert len(calls) == 3 and not cache.exists()
    assert "previous output failed validation" in calls[1]["messages"][-1]["content"]
    invalid = list(tmp_path.glob("response.invalid_*.json"))
    assert len(invalid) == (1 if recover else 3)
    for record in invalid:
        saved = json.loads(record.read_text())
        assert "detection" not in saved
        assert json.loads(saved["response_text"])["point_xy"] == [450, 500]
        assert "fake-secret" not in record.read_text()


def test_local_api_config_precedence_and_provenance_excludes_credentials(tmp_path, monkeypatch):
    for key in ("ARK_API_KEY", "DOUBAO_MODEL", "ARK_BASE_URL", "LLM_DB_API_KEY",
                "LLM_DB_MODEL", "LLM_DB_BASE_URL", "CUSTOM_TEST_KEY"):
        monkeypatch.delenv(key, raising=False)
    config = tmp_path / "config.py"
    config.write_text('LLM_DB_API_KEY="fake-local-secret"\nLLM_DB_MODEL="local-vision"\n'
                      'LLM_DB_BASE_URL="https://example.com/api/v3"\n')
    settings = load_api_settings(config_path=config)
    client = DoubaoGrounder(**settings)
    assert client.model == "local-vision" and client._api_key == "fake-local-secret"
    assert client.base_url == "https://example.com/api/v3"
    monkeypatch.setenv("ARK_API_KEY", "fake-env-secret")
    monkeypatch.setenv("DOUBAO_MODEL", "env-vision")
    assert load_api_settings(config_path=config)["model"] == "env-vision"
    assert load_api_settings(config_path=config)["api_key"] == "fake-env-secret"
    assert load_api_settings(config_path=config, model="cli-vision")["model"] == "cli-vision"
    settings = load_api_settings(config_path=config, key_env="CUSTOM_TEST_KEY")
    with pytest.raises(ValueError, match="missing API credential"):
        DoubaoGrounder(**settings, key_env="CUSTOM_TEST_KEY")
    (tmp_path / "doubao.py").write_text('"""Example executable code."""\n')
    assert [p.name for p in provenance_code_paths(tmp_path)] == ["doubao.py"]
    assert not (tmp_path / "__pycache__").exists()


def test_local_config_errors_hide_secret_source(tmp_path):
    config = tmp_path / "config.py"
    config.write_text('raise RuntimeError("fake-secret")\n')
    with pytest.raises(ValueError) as error:
        load_api_settings(config_path=config)
    assert "fake-secret" not in str(error.value) and error.value.__suppress_context__


def test_doubao_socket_timeout_retries_and_reports_sanitized_failure(tmp_path, monkeypatch):
    image = tmp_path / "final.png"
    Image.new("RGB", (10, 10)).save(image)
    calls = []

    class Opener:
        def open(self, req, timeout):
            calls.append(timeout)
            raise socket.timeout("fake-secret")

    monkeypatch.setattr("urllib.request.build_opener", lambda *args: Opener())
    monkeypatch.setattr("data_pipeline.doubao.time.sleep", lambda *args: None)
    with pytest.raises(RuntimeError, match="timed out") as error:
        DoubaoGrounder("test", api_key="fake-secret").identify(image, "goal", tmp_path / "cache.json")
    assert calls == [120., 120., 120.] and "fake-secret" not in str(error.value)
    assert not (tmp_path / "cache.json").exists()


def write_mesh(path):
    header = """ply
format binary_little_endian 1.0
element vertex 4
property float x
property float y
property float z
property uchar red
property uchar green
property uchar blue
element face 2
property list uchar int vertex_indices
property int object_id
end_header
"""
    vertices = np.zeros(4, dtype=[("xyz", "<f4", (3,)), ("rgb", "u1", (3,))])
    vertices["xyz"] = [[0, 2, 0], [1, 2, 0], [0, 2, 1], [9, 9, 9]]
    faces = np.zeros(2, dtype=[("n", "u1"), ("v", "<i4", (3,)), ("id", "<i4")])
    faces["n"], faces["v"], faces["id"] = 3, [[0, 1, 2], [1, 2, 3]], [7, 8]
    path.write_bytes(header.encode() + vertices.tobytes() + faces.tobytes())


def test_mesh_extracts_only_bound_object_and_converts_mp3d_axes(tmp_path):
    path = tmp_path / "scene_semantic.ply"
    write_mesh(path)
    model = extract_object_mesh(path, 7)
    assert model["faces"].tolist() == [[0, 1, 2]]
    np.testing.assert_array_equal(model["vertices_world"], [[0, 0, -2], [1, 0, -2], [0, 1, -2]])
    with pytest.raises(ValueError, match="no mesh faces"):
        extract_object_mesh(path, 9)


def test_annotation_overlay_apos_only_preserves_source_and_masks_opos(tmp_path, camera):
    pose, K = camera
    source = tmp_path / "source"
    source.mkdir()
    frames, samples = [], []
    for i, position in enumerate(trajectory(12)):
        body = np.eye(4)
        body[:3, 3] = position
        cam = pose.copy()
        cam[:3, 3] += position
        Image.new("RGB", (100, 100)).save(source / f"{i}.png")
        np.savez_compressed(source / f"{i}.npz", depth_m=np.full((100, 100), 9.),
                            valid=np.ones((100, 100), bool))
        frames.append(dict(frame_id=i, rgb=f"{i}.png", depth=f"{i}.npz",
                           world_from_body=body.tolist(), world_from_camera_cv=cam.tolist(),
                           world_from_depth_camera_cv=cam.tolist(),
                           next_expert_action=1))
        samples.append(dict(frame_id=i, next_expert_action=1, rvq_tokens="test",
                            history_start=0, history_end_inclusive=i))
    for name, records in [("frames", frames), ("samples", samples)]:
        (source / f"{name}.jsonl").write_text("\n".join(json.dumps(r) for r in records))
    (source / "episode.json").write_text(json.dumps(dict(complete=True, frames=12, episode_id="x",
        scene_id="synthetic", instruction="synthetic goal", camera={"K": K.tolist(), "width": 100, "height": 100})))
    (source / "manifest.json").write_text('{"format":"synthetic_test_only"}')
    np.savez_compressed(source / "targets.npz", fm_clean_se2_diff=np.zeros((12, 30, 3)))
    original = (source / "samples.jsonl").read_bytes()
    destination = tmp_path / "overlay"
    result = annotate_episode(source, destination, PointingConfig(), apos_only=True)
    (destination / "manifest.json").write_text(json.dumps({
        "format": "beta_nav_pointing_v1",
        "source_dataset": str(source), "source_manifest_sha256": sha256(source / "manifest.json"),
        "pointing_config": PointingConfig().metadata(), "episodes": ["x"]}))
    assert result["apos_valid"] == 8 and result["opos_valid"] == 0
    assert (source / "samples.jsonl").read_bytes() == original
    rows = [json.loads(s) for s in (destination / "samples.jsonl").read_text().splitlines()]
    assert all("next_expert_action" not in r for r in rows)
    assert all(r["opos_tokens"] is None for r in rows)
    with np.load(destination / "targets.npz") as data:
        assert not data["opos_valid_mask"].any()
        assert (data["opos_token_id"] == -1).all()
        np.testing.assert_array_equal(data["apos_target_frame_id"][-10:], np.full(10, 11))
        np.testing.assert_allclose(data["apos_target_world"][-10:], np.tile(trajectory(12)[-1], (10, 1)))
    # Validate expects run/episodes/<id>; use the same output in a real overlay layout.
    run = tmp_path / "run"
    (run / "episodes").mkdir(parents=True)
    (destination / "manifest.json").replace(run / "manifest.json")
    destination.rename(run / "episodes/x")
    assert validate_pointing(run)["apos_valid"] == 8
    # Enrich a historical overlay without grid fields, without touching its labels.
    legacy = tmp_path / "legacy"
    shutil.copytree(run, legacy)
    old_episode = legacy / "episodes/x"
    old_meta = json.loads((old_episode / "episode.json").read_text())
    old_meta.pop("pointing_grid")
    (old_episode / "episode.json").write_text(json.dumps(old_meta))
    old_rows = [json.loads(s) for s in (old_episode / "samples.jsonl").read_text().splitlines()]
    for row in old_rows:
        for channel in ("apos", "opos"):
            row[channel].pop("grid")
            row[channel].pop("pixel_rc")
    (old_episode / "samples.jsonl").write_text("\n".join(json.dumps(r) for r in old_rows))
    with np.load(old_episode / "targets.npz") as data:
        old_arrays = {k: data[k] for k in data.files if not k.endswith(("_grid_rc", "_grid_id", "_pixel_rc"))}
    np.savez_compressed(old_episode / "targets.npz", **old_arrays)
    old_hash = sha256(old_episode / "samples.jsonl")
    enriched = tmp_path / "grid_export"
    assert export_grid(legacy, enriched, "x")["apos_valid"] == 8
    assert sha256(old_episode / "samples.jsonl") == old_hash
    assert (enriched / "episodes/x/pointing_pixels.csv").is_file()
    assert not (enriched / "provenance/config.py").exists()
    with np.load(enriched / "episodes/x/targets.npz") as new_arrays:
        for name, values in old_arrays.items():
            np.testing.assert_array_equal(new_arrays[name], values)
        assert (new_arrays["opos_grid_id"] == -1).all()
    with pytest.raises(FileExistsError):
        export_grid(legacy, enriched, "x")
    book = np.zeros((2, 30), np.float32)
    book[1].reshape(10, 3)[:, 0] = .25
    bundle = RVQBundle(path=tmp_path, manifest={"stop": {"codes": [0, 0, 0]}}, levels=[2, 2, 2],
        horizon=10, representation="se2_diff", objective="ade_v1",
        encode={"type": "ade", "heading_weight": .3}, feature_space="weighted_diff",
        codebooks=[book, np.zeros_like(book), np.zeros_like(book)], jacobian_weights=np.ones(30),
        alpha={}, stop_l0=0)
    # Check the collector's revised export contract with actual RVQ computation.
    export_targets(source, frames, bundle, True, {"K": K}, PointingConfig())
    emitted = [json.loads(s) for s in (source / "samples.jsonl").read_text().splitlines()]
    assert len(emitted) == 12 and emitted[-1]["explicit_stop"]
    assert sum(s["apos"]["loss_valid"] for s in emitted) == 8
    assert all("next_expert_action" not in s for s in emitted)
    assert all(s["apos_tokens"] is None or s["apos"]["token_id"] <= 1296 for s in emitted)
    assert all(s["opos"]["target_frame_id"] == 11 for s in emitted)
    assert emitted[-1]["opos"]["state"] == "not_visible"
    assert emitted[-1]["opos_tokens"] == "<opos_0>"
    with np.load(source / "targets.npz") as data:
        np.testing.assert_array_equal(data["opos_target_frame_id"], np.full(12, 11))
        np.testing.assert_allclose(data["opos_target_world"], np.tile(trajectory(12)[-1], (12, 1)))
        assert (data["opos_grid_id"][data["opos_token_id"] == 0] == -1).all()
