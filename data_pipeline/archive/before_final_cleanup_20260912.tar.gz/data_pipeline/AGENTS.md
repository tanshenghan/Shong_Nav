# Data pipeline working rules

The user designated this directory as the permanent home for data-pipeline work.

- Keep collection, conversion, labeling, sampling and validation implementations,
  pipeline documentation, future configuration, tests and small reports here.
- Update `README.md` whenever the generation paradigm or primary entry point changes.
  Document command parameters in `docs/`; link them from the repository's
  `docs/CONFIGURATION.md` index.
- Keep raw datasets, RGB/depth collections and codebook assets under the configured
  data root (currently `/mnt/cfs/data/beta_nav`). Local environments belong in the
  ignored `.venv/` directory. Do not commit environment packages or large media.
- Preserve source/label provenance, coordinate frames, physical units, sampling
  definitions, independent loss masks and codebook versions in generated manifests.
- Current agreed paradigm: R2R route/actions, start state and instruction; fresh
  LightNav-configured Habitat-Sim RGB/depth/body/camera poses; 470x280, HFOV 120°,
  height 0.88 m, pitch 0°; RVQ horizon 10 and FM horizon 30.
- Current pointing definition: apos targets ground position min(t+10, N-1),
  falling back backwards along the future path to the nearest visible point.
  Always retain target_world_point, including the terminal 3D target in the last
  ten frames. No visible candidate means pixel supervision is unknown/masked.
  Never output apos turn/STOP markers. Historical configs without tail_policy
  retain their original masked-tail behavior when validating existing data.
- Save explicit original-image pixel_rc and 48x27 grid row/col/cell_id for valid
  apos/opos points. Rows/cols are zero-based; spatial IDs are 1+row*48+col.
  Missing spatial locations stay null in JSON and -1 in integer arrays, including
  the opos=0 not-visible class. Never invent a grid cell for an offscreen target.
- Default opos_mode=terminal_ground: opos is the final destination, exactly the
  recorded terminal world_from_body[:3,3], fixed across all frames. Project using
  each saved camera pose, intrinsics and depth; never backtrack or replace the
  destination with another visible point. Always save target_world_point and
  target_frame_id, even when no spatial pixel is visible. This mode requires no
  API, object recognition, semantic assets or semantic replay. New collection and
  offline annotation both produce this label. Missing historical opos_mode means
  the old doubao semantics; do not reinterpret historical labels.
- Optional legacy opos_mode=doubao searches max(0,N-8) through N-1, using
  Doubao candidate RGB + instruction grounding. Select the first confident,
  geometrically bindable destination; advance on a miss or failed binding.
  Object targets bind an existing MP3D semantic instance and its world mesh;
  render the same instance at all recorded poses, rejecting unrelated depth.
  Stop-location regions must contain the visible terminal recorded ground point;
  keep that exact world point fixed and project it with per-frame depth checks.
  Preserve per-candidate API records and opos_search.json. API failures remain
  failures; no identified target means unknown, not negative supervision.
  Missing API credentials must be reported, never replaced with invented detections.
- Local config.py supplies LLM_DB_BASE_URL, LLM_DB_API_KEY and LLM_DB_MODEL.
  Keep it ignored by Git and excluded from provenance copies/hashes and logs.
  The Doubao prompt and request instruction prefix are English.
- Do not export forward/left/right action labels in new training samples/frames.
  Internal expert action replay remains until the user requests continuous resampling.
- Use a new annotation overlay for old data. Preserve historical data/provenance.
- Do not treat record FPS as physical action timing, EOF as STOP, unknown object
  labels as not-visible labels, or decoded RVQ trajectories as clean FM ground truth.
- Maintain CPU geometry tests in `tests/` within this directory. `make test` from
  the repository root includes them. Use dry runs for entry-point/path-only changes;
  regenerating GPU datasets is unnecessary for a directory reorganization.
