"""CPU geometry for ten-step ground pointing and semantic-instance object points."""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np

from lightnav.vln_utils import POINT_GRID_H, POINT_GRID_W, encode_point_pixel


@dataclass(frozen=True)
class PointingConfig:
    horizon: int = 10
    tail_policy: str = "terminal"
    path_spacing_m: float = .02
    depth_tolerance_m: float = .05
    depth_relative_tolerance: float = .01
    min_object_pixels: int = 12
    min_box_coverage: float = .6
    min_detection_confidence: float = .6
    opos_search_frames: int = 8
    opos_mode: str = "terminal_ground"

    def __post_init__(self):
        if self.opos_mode not in ("terminal_ground", "doubao"):
            raise ValueError("opos_mode must be terminal_ground or doubao")
        if self.tail_policy not in ("terminal", "mask"):
            raise ValueError("tail_policy must be terminal or mask")
        if self.horizon != 10 or not 0 < self.path_spacing_m <= 1:
            raise ValueError("apos requires horizon=10 and spacing in (0, 1] metres")
        if not 0 <= self.depth_tolerance_m <= 1 or not 0 <= self.depth_relative_tolerance <= .1:
            raise ValueError("invalid depth tolerance")
        if self.min_object_pixels < 1:
            raise ValueError("min_object_pixels must be positive")
        if type(self.opos_search_frames) is not int or self.opos_search_frames < 1:
            raise ValueError("opos_search_frames must be a positive integer")
        if not 0 < self.min_box_coverage <= 1 or not 0 <= self.min_detection_confidence <= 1:
            raise ValueError("invalid object binding thresholds")

    def metadata(self):
        return asdict(self)

    @classmethod
    def from_metadata(cls, metadata):
        """Old datasets masked the tail; do not reinterpret historical labels."""
        return cls(**{"tail_policy": "mask", "opos_search_frames": 1, "opos_mode": "doubao", **metadata})


def project_world(points, world_from_camera, K):
    points = np.asarray(points, dtype=np.float64).reshape(-1, 3)
    camera_from_world = np.linalg.inv(np.asarray(world_from_camera))
    xyz = points @ camera_from_world[:3, :3].T + camera_from_world[:3, 3]
    projected = xyz @ np.asarray(K).T
    uv = np.full((len(points), 2), np.nan)
    front = xyz[:, 2] > 1e-6
    uv[front] = projected[front, :2] / projected[front, 2:]
    return uv, xyz[:, 2]


def backproject_pixels(uv, depth, world_from_camera, K):
    """Image-edge coordinates: integer array pixel (row,col) has centre +0.5."""
    uv = np.asarray(uv, dtype=np.float64).reshape(-1, 2)
    rays = np.c_[uv, np.ones(len(uv))] @ np.linalg.inv(K).T
    xyz = rays * np.asarray(depth).reshape(-1, 1)
    transform = np.asarray(world_from_camera)
    return xyz @ transform[:3, :3].T + transform[:3, 3]


def unknown_point(reason):
    return {"state": "unknown", "pixel": None, "world_point": None,
            "token_id": -1, "loss_valid": False, "reason": reason}


def pixel_grid_metadata(width, height):
    return {"version": 1, "image_size_wh": [int(width), int(height)],
            "grid_shape_rc": [POINT_GRID_H, POINT_GRID_W], "index_base": 0,
            "pixel_order": "[u, v] = [x, y]", "pixel_rc_order": "[row, col]",
            "grid_rc_order": "[row, col]", "cell_id_formula": "1 + row * 48 + col",
            "missing_array_index": -1, "reference": "original RGB, before video scaling or padding"}


def attach_pixel_grid(point, width, height):
    """Expose both original-image pixel indices and the existing model grid cell.

    Does not select a point or change geometry/tokens. Missing spatial labels,
    including the valid opos=0 not-visible class, have no pixel or grid cell.
    """
    result = {**point, "pixel_rc": None, "grid": None}
    if point["state"] != "point" or not point["loss_valid"]:
        return result
    pixel = np.asarray(point["pixel"], dtype=float)
    if (width <= 0 or height <= 0 or pixel.shape != (2,) or not np.isfinite(pixel).all()
            or not (0 <= pixel[0] < width and 0 <= pixel[1] < height)):
        raise ValueError("cannot assign a grid cell to an invalid/out-of-image pixel")
    tid = encode_point_pixel(*pixel, width, height)
    if point["token_id"] != tid:
        raise ValueError("point token disagrees with its pixel/grid cell")
    col, row = np.floor(pixel).astype(int)
    result["pixel_rc"] = [int(row), int(col)]
    result["grid"] = {"row": (tid - 1) // POINT_GRID_W, "col": (tid - 1) % POINT_GRID_W,
                      "cell_id": tid}
    return result


def pixel_grid_arrays(points, channel):
    return {
        channel + "_pixel_rc": np.asarray([p["pixel_rc"] if p["pixel_rc"] is not None
                                          else [-1, -1] for p in points], dtype=np.int32),
        channel + "_grid_rc": np.asarray([[p["grid"]["row"], p["grid"]["col"]]
                                         if p["grid"] is not None else [-1, -1]
                                         for p in points], dtype=np.int32),
        channel + "_grid_id": np.asarray([p["grid"]["cell_id"] if p["grid"] is not None
                                         else -1 for p in points], dtype=np.int32),
    }


def ground_target_arrays(points, channel="apos"):
    """Intended 3D targets are independent of selected visible-point labels."""
    if not all("target_world_point" in p for p in points):
        return {}
    return {
        channel + "_target_world": np.asarray([p["target_world_point"] for p in points], dtype=np.float64),
        channel + "_target_frame_id": np.asarray([p["target_frame_id"] for p in points], dtype=np.int32),
    }


def ground_point(positions, t, world_from_camera, K, depth, depth_valid, config):
    """Prefer exactly t+10; otherwise walk backwards along that future polyline.

    The first visible candidate is nearest in *path arclength* to t+10, to within
    path_spacing_m. Body origins are the recorded feet/navmesh ground positions.
    When t+10 is unavailable, use the recorded terminal ground position. Keep
    this 3D target even when no visible pixel exists; pixel loss stays masked.
    """
    positions = np.asarray(positions, dtype=np.float64)
    end = t + config.horizon
    if end >= len(positions):
        if config.tail_policy == "mask":
            return unknown_point("missing_t_plus_10")
        end = len(positions) - 1
    target = ({"target_frame_id": end, "target_world_point": positions[end].tolist()}
              if config.tail_policy == "terminal" else {})
    exact_reason = "terminal_ground_point" if t + config.horizon >= len(positions) else "t_plus_10"
    candidates, indices, backtracks = [positions[end]], [float(end)], [0.]
    travelled = 0.
    for j in range(end, t, -1):
        length = float(np.linalg.norm(positions[j] - positions[j - 1]))
        if length <= 1e-9:
            continue
        count = int(np.ceil(length / config.path_spacing_m))
        for k in range(1, count + 1):
            fraction = k / count
            candidates.append(positions[j] * (1 - fraction) + positions[j - 1] * fraction)
            indices.append(j - fraction)
            backtracks.append(travelled + length * fraction)
        travelled += length
    candidates = np.asarray(candidates)
    uv, z = project_world(candidates, world_from_camera, K)
    height, width = depth.shape
    inside = (np.isfinite(uv).all(1) & (z > 1e-6) & (uv[:, 0] >= 0)
              & (uv[:, 0] < width) & (uv[:, 1] >= 0) & (uv[:, 1] < height))
    for i in np.flatnonzero(inside):
        col, row = np.floor(uv[i]).astype(int)
        observed = float(depth[row, col])
        if not depth_valid[row, col] or not np.isfinite(observed) or observed <= 0:
            continue
        tolerance = config.depth_tolerance_m + config.depth_relative_tolerance * observed
        if z[i] > observed + tolerance:
            continue
        return {**target, "state": "point", "pixel": uv[i].tolist(),
                "world_point": candidates[i].tolist(),
                "token_id": encode_point_pixel(*uv[i], width, height), "loss_valid": True,
                "target_frame_id": end, "selected_frame_fraction": indices[i],
                "backtrack_m": backtracks[i],
                "reason": exact_reason if i == 0 else "visible_path_backtrack"}
    return {**unknown_point("no_visible_ground_point"), **target}


def fixed_world_point(world_point, world_from_camera, K, depth, depth_valid, config):
    """Visibility of a confirmed, fixed destination on the recorded ground plane."""
    uv, z = project_world([world_point], world_from_camera, K)
    height, width = depth.shape
    pixel = uv[0]
    invisible = {"state": "not_visible", "pixel": None, "world_point": None,
                 "token_id": 0, "loss_valid": True}
    if (z[0] <= 1e-6 or not np.isfinite(pixel).all() or not
            (0 <= pixel[0] < width and 0 <= pixel[1] < height)):
        return {**invisible, "reason": "stop_location_outside_view"}
    col, row = np.floor(pixel).astype(int)
    observed = float(depth[row, col])
    if not depth_valid[row, col] or not np.isfinite(observed) or observed <= 0:
        return unknown_point("stop_location_depth_unknown")
    tolerance = config.depth_tolerance_m + config.depth_relative_tolerance * observed
    if z[0] > observed + tolerance:
        return {**invisible, "reason": "stop_location_occluded"}
    return {"state": "point", "pixel": pixel.tolist(),
            "world_point": np.asarray(world_point).tolist(),
            "token_id": encode_point_pixel(*pixel, width, height), "loss_valid": True,
            "reason": "visible_terminal_ground_location"}


def terminal_ground_point(positions, world_from_camera, K, depth, depth_valid, config):
    """opos is the final recorded destination, independent of visual recognition.

    Always retain its world coordinate and target frame, including when the
    destination is occluded, outside the view, or under the terminal camera.
    """
    positions = np.asarray(positions, dtype=np.float64)
    if positions.ndim != 2 or positions.shape[1] != 3 or not len(positions):
        raise ValueError("positions must be a nonempty (N,3) array")
    goal = positions[-1]
    if not np.isfinite(goal).all():
        raise ValueError("terminal destination must be finite")
    point = fixed_world_point(goal, world_from_camera, K, depth, depth_valid, config)
    return {**point, "target_frame_id": len(positions) - 1, "target_world_point": goal.tolist()}


def bind_stop_location(detection, terminal_world, frame, K, depth, depth_valid, config):
    """Accept an identified stop region only if it contains the visible GT endpoint.

    Uses freshly recorded Habitat body coordinates, not a guessed bbox center or
    the depth surface of an unrelated object. The detector's region supplies the
    semantic evidence; the recorded endpoint supplies the exact stopping point.
    """
    if not detection["found"] or detection["confidence"] < config.min_detection_confidence:
        return {"bound": False, "reason": "no_confident_stop_region"}
    point = fixed_world_point(terminal_world, frame["world_from_camera_cv"], K,
                              depth, depth_valid, config)
    if point["state"] != "point":
        return {"bound": False, "reason": "anchor_" + point["reason"]}
    height, width = depth.shape
    x0, y0, x1, y1 = np.asarray(detection["bbox_xyxy"]) * [width, height, width, height]
    u, v = point["pixel"]
    if not (x0 <= u < x1 and y0 <= v < y1):
        return {"bound": False, "reason": "terminal_ground_outside_detected_stop_region"}
    return {"bound": True, "reason": "confirmed_terminal_ground_in_stop_region",
            "target_type": "stop_location", "model_kind": "recorded_terminal_ground_point",
            "world_point": np.asarray(terminal_world).tolist(), "anchor_pixel": point["pixel"]}


def bind_instance(detection, semantic, known_ids, config):
    """Bind Doubao's interior point to one MP3D object, then check box agreement.

    Semantic pixels contain object IDs directly; semantic_index_to_object_index
    maps the HOUSE segment IDs and must NOT be applied to sensor object IDs.
    """
    if not detection["found"]:
        return {"bound": False, "reason": "no_terminal_target"}
    if detection["confidence"] < config.min_detection_confidence:
        return {"bound": False, "reason": "low_detection_confidence"}
    h, w = semantic.shape
    x0, y0, x1, y1 = np.asarray(detection["bbox_xyxy"]) * [w, h, w, h]
    u, v = np.asarray(detection["point_xy"]) * [w, h]
    col, row = int(np.floor(u)), int(np.floor(v))
    sid = int(semantic[row, col])
    if sid <= 0 or sid not in known_ids:
        return {"bound": False, "reason": "point_has_no_semantic_instance"}
    ys, xs = np.nonzero(semantic == sid)
    in_box = (xs + .5 >= x0) & (xs + .5 < x1) & (ys + .5 >= y0) & (ys + .5 < y1)
    inside_count = int(in_box.sum())
    coverage = float(in_box.mean())
    if inside_count < config.min_object_pixels or coverage < config.min_box_coverage:
        return {"bound": False, "reason": "box_instance_disagreement", "semantic_id": sid,
                "box_coverage": coverage, "inside_pixels": inside_count}
    return {"bound": True, "semantic_id": sid, "box_coverage": coverage,
            "inside_pixels": inside_count, "reason": "interior_point_and_instance_mask"}


def object_point(semantic, semantic_id, depth, depth_valid, world_from_camera, K, config,
                 *, world_bounds=None):
    """Choose a real visible surface pixel, avoiding bbox centres on background."""
    mask = semantic == semantic_id
    count = int(mask.sum())
    if count == 0:
        return {"state": "not_visible", "pixel": None, "world_point": None,
                "token_id": 0, "loss_valid": True, "reason": "instance_not_rendered",
                "visible_pixels": 0}
    usable = mask & depth_valid & np.isfinite(depth) & (depth > 0)
    rows, cols = np.nonzero(usable)
    if len(rows) < config.min_object_pixels:
        return {**unknown_point("too_few_valid_instance_pixels"), "visible_pixels": count}
    pixels = np.c_[cols + .5, rows + .5]
    world = backproject_pixels(pixels, depth[rows, cols], world_from_camera, K)
    if world_bounds is not None:
        # RGB/depth GLB and semantic PLY need not share exactly the same edges.
        # Keep only depth surfaces consistent with the bound instance's 3D extent.
        bounds = np.asarray(world_bounds)
        tolerance = config.depth_tolerance_m + config.depth_relative_tolerance * depth[rows, cols]
        inside = ((world >= bounds[0] - tolerance[:, None]).all(1)
                  & (world <= bounds[1] + tolerance[:, None]).all(1))
        pixels, world = pixels[inside], world[inside]
        if len(pixels) < config.min_object_pixels:
            return {**unknown_point("instance_depth_outside_mesh"), "visible_pixels": count}
    # The closest actual instance pixel to its median stays on the visible surface.
    center = np.median(pixels, axis=0)
    index = np.argmin(np.sum((pixels - center) ** 2, axis=1))
    pixel = pixels[index]
    point = world[index]
    h, w = depth.shape
    return {"state": "point", "pixel": pixel.tolist(), "world_point": point.tolist(),
            "token_id": encode_point_pixel(*pixel, w, h), "loss_valid": True,
            "visible_pixels": count, "reason": "visible_instance_surface"}
