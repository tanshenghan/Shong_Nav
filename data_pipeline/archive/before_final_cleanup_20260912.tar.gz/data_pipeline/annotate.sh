#!/usr/bin/env bash
set -euo pipefail
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BETA_HABITAT_PYTHON=${HABITAT_PYTHON:-/mnt/pfs/jiayilin/Image2Sim-Robot/envs/habitat-image2sim/bin/python}
cd "$REPO"
exec env -u CUDA_VISIBLE_DEVICES \
  PYTHONPATH="$REPO/data_pipeline/.venv/deps${PYTHONPATH:+:$PYTHONPATH}" \
  PYTHONDONTWRITEBYTECODE=1 HABITAT_SIM_LOG=quiet MAGNUM_LOG=quiet \
  __EGL_VENDOR_LIBRARY_FILENAMES=/usr/share/glvnd/egl_vendor.d/10_nvidia.json \
  LD_PRELOAD=/lib/x86_64-linux-gnu/libGLdispatch.so.0 \
  "$BETA_HABITAT_PYTHON" "$REPO/data_pipeline/annotate_r2r.py" "$@"
