# 数据生成管线

**本目录是后续所有数据管线相关工作的统一入口。** 采集、转换、标注、采样、
校验代码，以及设计文档、配置、测试和小型验证报告，均在这里维护。
实际生成的大型数据保存在 `/mnt/cfs/data/beta_nav/`。

## 当前采用的生成范式

```text
R2R 的场景、起点、指令及 GT 路线 / 专家动作
  → 用 LightNav 相机和运动配置在 Habitat-Sim 中重新执行路线
  → 每步采集新的 RGB、深度、机体位姿与相机位姿
  → 从实际采集位姿构建未来轨迹
  → 前 10 步编码为 RVQ，前 30 步保留为连续 FM 真值
  → min(t+10, 末帧) 地面点作为 apos 目标；不可见时沿未来轨迹回退到最近可见点
  → 将实际末帧的三维落地点固定为整条轨迹的最终目的地 opos
  → 用各帧相机和深度投影同一个终点，保存可见像素、网格与不可见状态
  → 独立生成各标签的有效 mask
  → 检查回放偏差、图像、深度、坐标及动作对齐，保存数据与 provenance
```

R2R 不提供本管线的录制 RGB、深度、相机标定或逐帧位姿标签；这些观测和标签
来自新的仿真回放。R2R 起点用于初始化，GT 路线用于执行与检查。LightNav 神经
模型不参与生成运动 GT。默认 `opos_mode=terminal_ground`，直接使用专家终点，
无需豆包或语义资产。旧版末八帧识别保留为显式 `--opos-mode doubao` 选项。
新训练样本不输出前进/左转/右转标签；当前内部仍用专家动作回放轨迹。
**新版 pointing 定义、实现和命令见 [POINTING.md](docs/POINTING.md)。**
FM、RVQ、apos、opos 四类 GT 的构造、数组读取、独立 mask 及第 20 帧完整实例见
[GT_CONSTRUCTION.md](docs/GT_CONSTRUCTION.md)。
与 InternNav 的 FM 动作定义对照见
[INTERNNAV_FM_COMPARISON.md](docs/INTERNNAV_FM_COMPARISON.md)。

| 项目 | 当前约定 |
|---|---|
| 图像尺寸 | 原生渲染宽 470 × 高 280，RGB/深度对齐 |
| 相机 | 水平 FOV 120°，离地 0.88 m，俯仰角 0° |
| 内参 | fx = fy ≈ 135.6773133，cx = 235，cy = 140 |
| 深度 | float32、米制 camera-Z，0–10 m；保存有效像素 mask |
| 原始位姿 | 每帧 `world_from_body`、`world_from_camera_cv` 及深度相机位姿 |
| 动作坐标 | forward 米、left 米、逆时针 yaw 弧度 |
| RVQ | 未来 10 步，固定 3 × 256 码本，3 个动作 token |
| FM | 未来 30 步、`[30,3]` 的量化前 `se2_diff` |
| apos | min(t+10, N-1) 地面点；保留三维目标，遮挡/视野外时沿路径反向搜索最近可见点 |
| opos | 固定为实际末帧三维地面坐标；每帧投影同一点，不回退；不可见仍保留三维目标 |
| 采样步 | 连续专家动作记录步；`physical_dt_s=null` |
| 训练划分 | R2R train；按 scene/trajectory 去重选路线 |
| 仿真环境 | 独立 Python 3.9 + Habitat-Sim 0.3.3；不混入推理虚拟环境 |

目前 motion primitive 为前进 0.25 m、转向 15°，取自 LightNav 配置。采集的
470×280 与后续模型预处理尺寸是两个阶段；模型输入仍需遵守 checkpoint 的约定。

## 标签对齐与质量规则

1. 当前观测 `t` 在执行内部专家动作 **之前**保存，未来标签始于 `t+1`；不导出动作类别标签。
2. RVQ 和 FM 共享真实轨迹的前 10 步。FM 不使用 RVQ 重建轨迹作为真值。
3. 朝向来自实际旋转，保留原地转向；不从 XY 路径切线推测 yaw。
4. `fm_waypoints_ego` 表示未来路点相对当前机体；`fm_clean_se2_diff` 的每一步
   相对前一步局部坐标。高度变化另存，平面 SE(2) 不表示楼梯的垂直运动。
5. FM 尾部未知未来按步 mask，RVQ 不完整 chunk 整体 mask。存储补齐值不是标签。
6. 最后一个 STOP 需要显式专家 STOP 和到目标距离检查；EOF 不自动产生 STOP。
7. 30 个未来动作步与 FM 流积分次数不同；视频 FPS 不代表机器人控制周期。
8. 只使用 `episode.json` 中 `complete=true` 的 episode。保存配置、代码及码本
   哈希、来源和检查结果，不覆盖历史采集数据及 provenance 快照。

RVQ 编码采用新实现的逐级 ADE + 0.3 × 末端朝向误差搜索。固定发布码本不变，
但不声称逐 bit 复现未公开的官方训练编码器。FM 训练时再采样噪声/流时间，
并采用只基于训练集确定的归一化；当前交付的是数据，不包含 FM 训练。

## 目录与入口

```text
data_pipeline/
  README.md                  总入口与当前生成范式
  AGENTS.md                  后续维护约定
  collect_r2r.py             R2R 专家路线回放、传感器采集及标签导出
  geometry.py                坐标转换、未来轨迹、RVQ 编码与路线偏差检查
  pointing.py                apos 第 10 步/回退、opos 固定终点及投影可见性
  doubao.py                  候选 RGB + 指令的豆包 API 物体/停止区域识别
  destination.py             倒数 8 帧顺序查找、三维目标确认及逐帧识别记录
  config.py                  本机豆包地址、密钥和模型；Git 忽略、不复制到数据集
  semantic_scene.py          Habitat 语义回放与 MP3D 物体网格提取
  annotate_r2r.py            对已有数据生成 apos/opos 补标版本
  export_pointing_grid.py    离线补存像素行列、48×27 网格行列及编号，输出 CSV
  rollout_lightnav.py        真实 LightNav 闭环导航、原始预测记录和预测视频
  annotate.sh                Habitat 环境补标入口，旧版豆包物体模式需要此环境
  configs/pointing.json      几何、遮挡、目标绑定阈值
  validate_r2r.py             已保存数据的逐帧与跨帧几何验证
  validate_pointing.py        补标数据的源哈希、坐标、可见性与 token 验证
  run.sh                     本机运行入口，可覆盖解释器、GPU 和数据路径
  docs/R2R_COLLECTION.md     完整格式、坐标定义与 CLI 参数
  tests/test_collection.py   CPU 几何与动作对齐测试
  tests/test_pointing.py     pointing 几何、API 契约及三维模型测试
  reports/pilot_20260911.json 首批数据统计与验证结果
  .venv/                     被 git 忽略的本地运行依赖
```

完整参数、数组字段和读取约定见 [R2R_COLLECTION.md](docs/R2R_COLLECTION.md)。
采集脚本逐步讲解和当前 apos/opos 补标流程见
[COLLECTOR_WALKTHROUGH.md](docs/COLLECTOR_WALKTHROUGH.md)。
当前复用的相机配置来自
[LightNav Habitat 配置](../habitat_server/configs/vlnce_r2r.yaml)，
共享 RVQ 解码器来自 [traj_vocab.py](../src/lightnav/traj_vocab.py)。
以后新增的管线专用配置放入本目录的 `configs/`。

## 运行与验证

从仓库根目录运行。本机入口默认使用已验证的独立 Habitat-Sim 解释器；
`HABITAT_PYTHON` 可覆盖它，`BETA_GPU_ID` 可选择渲染 GPU（默认 3）。

```bash
# 只检查配置和源文件，不写数据、不启动 GPU 渲染
bash data_pipeline/run.sh /mnt/cfs/data/beta_nav/NEW_RUN 10 --dry-run

# 采集 10 条不同的训练路线；目录必须是新的
bash data_pipeline/run.sh /mnt/cfs/data/beta_nav/NEW_RUN 10

# -1 表示所有不同的训练路线，每条路线选一条指令
bash data_pipeline/run.sh /mnt/cfs/data/beta_nav/NEW_FULL_RUN -1

# 读取已有数据并打印验证结果；不修改已有数据
.venv/bin/python data_pipeline/validate_r2r.py \
  /mnt/cfs/data/beta_nav/r2r_train_470x280_20260911

# 将新的验证报告保存在管线目录
.venv/bin/python data_pipeline/validate_r2r.py \
  /mnt/cfs/data/beta_nav/r2r_train_470x280_20260911 \
  --report data_pipeline/reports/NEW_VALIDATION.json

# CPU 补标：apos 未来十步，opos 最终目的地；不需要 API 或 Habitat
.venv/bin/python data_pipeline/annotate_r2r.py /mnt/cfs/data/beta_nav/r2r_train_470x280_20260911 \
  --output-dir /mnt/cfs/data/beta_nav/r2r_pointing_NEW_RUN \
  --episode-id 2864 --episodes 1

# 管线测试；仓库的 make test 也会包含这些测试
PYTHONPATH=src .venv/bin/python -m pytest -q data_pipeline/tests
```

`run.sh` 的位置参数依次为新输出目录、路线数量（默认 10）；其余参数原样传给
`collect_r2r.py`。环境变量 `BETA_DATA_ROOT`、`BETA_SCENES_DIR`、`BETA_RVQ_BUNDLE`
分别覆盖 R2R 数据根目录、场景目录和动作码本路径。
其他机器需自行指定已安装依赖的 Habitat 解释器，入口不自动安装或修改共享环境。

旧的 `scripts/collect_beta_nav.py` 保留为转发入口，以兼容已经保存的重跑命令。
管线实现在本目录维护，不在旧路径继续增加逻辑。

## GT 视频

用户指定的视频渲染代码位于
[`visual/render_episode_gt.py`](../visual/render_episode_gt.py)，用单个 Python 文件完成：
顶部显示 Instruction，画出真实未来 10 步 GT 轨迹线，并叠加已有的有效 apos/opos。
使用方法及全部参数见 [VISUALIZATION.md](docs/VISUALIZATION.md)。
已生成视频位于 `/mnt/cfs/data/beta_nav/visual/episode_2864_gt10_topview_20260911.mp4`。
同一文件也支持 `--output IMAGE.png --frame-id 0 --channel apos`，生成带完整网格、
格子高亮、精确像素及局部放大的静态图。
第 0 帧示意图位于 `/mnt/cfs/data/beta_nav/visual/episode_2864_frame_000000_apos_grid_20260912.png`。
当前终点标签的最新视频为
`/mnt/cfs/data/beta_nav/visual/episode_2864_gt_opos_endpoint_rings_20260912.mp4`，
重合的 apos/opos 使用同心双环显示；训练像素和坐标不变。

## 首批数据记录

2026-09-12 按“opos 是最终要去的地方”重新生成 2864，当前版本为
`/mnt/cfs/data/beta_nav/r2r_2864_opos_endpoint_20260912/episodes/2864`。
52 帧均保留末帧 51 的固定三维地面目标；第 11–46 帧有可见 opos，共 36 帧，
其余 16 帧为 `<opos_0>`。apos 仍有 38 个有效点，21 个非 opos 数组与上一版完全一致。
本次不调用 API；几何验证及 70 项管线测试通过，详见
[固定终点报告](reports/episode_2864_opos_endpoint_20260912.json)。
视频：`/mnt/cfs/data/beta_nav/visual/episode_2864_gt_opos_endpoint_20260912.mp4`，
52 帧、5 FPS、10.4 秒；第 44 帧像素格子示意图为
`/mnt/cfs/data/beta_nav/visual/episode_2864_frame_000044_opos_endpoint_grid_20260912.png`。

以下倒数八帧结果使用历史豆包语义，不是当前默认的终点 opos。
2026-09-12 按倒数八帧顺序完成 2864 的 opos 重标，结果位于
`/mnt/cfs/data/beta_nav/r2r_2864_opos_tail8_20260912_v2`。已实际检查 44→51 帧：
第 44 帧识别区域不包含 GT 终点；47、49、50 帧的真实终点在视野外；
其余帧未可靠识别。最终未绑定目标，52 帧 opos 仍为 unknown/mask=false。
全部候选 API 响应、拒绝原因、像素 CSV 和本地对照图已保存；apos、RVQ/FM
及位姿数组保持原值。详见 [末八帧重标报告](reports/episode_2864_opos_tail8_20260912.json)。
不带 `_v2` 的目录保留首次坐标格式校验失败的记录，不作为完整数据。

真实模型导航另用 [LIGHTNAV_ROLLOUT.md](docs/LIGHTNAV_ROLLOUT.md) 的入口：
LightNav 根据每步实际观察预测 RVQ 轨迹并驱动 Habitat 连续速度控制，保存新的
RGB/深度/位姿、模型原始 token、预测 apos/opos 及可视化视频。该输出是模型
rollout，不作为专家运动 GT；已有训练标签规则不改变发布权重的原始预测语义。

2026-09-12 已实际运行 episode 2864：
`/mnt/cfs/data/beta_nav/lightnav_2864_closed_loop_20260912`。
61 次模型预测、62 个实际观察，模型主动 STOP，终点距 R2R 目标约 0.344 m。
模型给出 60 个空间 apos 和 1 个 apos STOP；opos 为 29 个空间点、32 次不可见。
预测视频为目录中的 `lightnav_navigation.mp4`（5 FPS，12.4 秒）。
全部 RVQ 解码、控制旋转、相机位姿、RGB/深度和视频帧检查通过，详见
[真实模型运行报告](reports/episode_2864_lightnav_rollout_20260912.json)。

2026-09-12 为 2864 补充了明确的二维像素和网格地址，新目录为
`/mnt/cfs/data/beta_nav/r2r_2864_gt_grid_20260912/episodes/2864`。
每个有效 apos/opos 保存 `pixel`、`pixel_rc` 和 `grid`（行、列、格子编号）；
JSON、NPZ 和 `pointing_pixels.csv` 均可读取。52 帧中仍有 38 帧有效 apos，
几何标签保持原值，未再次请求豆包。字段与离线升级命令见
[二维像素与具体网格](docs/POINTING.md#二维像素与具体网格)。

2026-09-11 单条新版 GT 位于
`/mnt/cfs/data/beta_nav/r2r_2864_gt_20260911_v2/episodes/2864`：52 帧，38 个有效 apos，
最后十帧三维目标全部指向 frame 51。保留 42 个完整 RVQ-10 chunk、1 个显式 STOP
及 22 个完整 FM-30 chunk，其余未来步按 mask 使用。
真实豆包返回 `found=false`：指令指定的左侧第二个门在末帧不可见，因此 52 帧
opos 均为 unknown，未生成物体网格。该结果不能用于正/负 opos 监督。
详见 [本次生成报告](reports/episode_2864_gt_20260911.json) 和
[逐帧验证](reports/episode_2864_gt_validation_20260911.json)。
不带 `_v2` 的同名单条目录保留首次请求超时的失败记录，不作为训练数据。

以下为历史 v1 采集。新版 apos 补标位于
`/mnt/cfs/data/beta_nav/r2r_train_470x280_apos10_20260911`，506 帧中有 364 个有效 apos；
其 opos 因该次明确使用 `--apos-only` 而保持 unknown，尾部沿用当时的 mask 规则。
当前新数据采用末帧三维目标补齐 apos，opos 直接使用固定专家终点。
仅旧版豆包模式从本机 `config.py` 读取 API 配置。

数据目录：`/mnt/cfs/data/beta_nav/r2r_train_470x280_20260911`。

- 10 条轨迹、506 帧 RGB/深度/位姿。
- 406 个完整 RVQ motion chunk，另有 10 个经验证的 STOP 标签。
- 206 个完整 FM 30 步 chunk，尾部仍保留部分有效监督。
- 50 对转向帧的深度重投影误差中位数约 2.95 mm。
- 新位姿与 GT 路线最大偏差约 5.8e-8 m。
- 本采样定义下 RVQ 重建平均 ADE 约 9.84 cm，不能作为官方编码器精度报告。

验证细节见 [首批报告](reports/pilot_20260911.json)。后续变更在本目录更新范式、
代码与说明，生成的新数据写入独立版本目录。
