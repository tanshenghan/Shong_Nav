"""MP3D semantic replay and extraction of an existing object mesh in Habitat axes."""

from __future__ import annotations

import copy
from pathlib import Path

import numpy as np

from data_pipeline.collect_r2r import Renderer

# Native MP3D semantic PLY: +Z up. Habitat world: +Y up.
WORLD_FROM_MP3D = np.array([[1., 0., 0., 0.], [0., 0., 1., 0.],
                            [0., -1., 0., 0.], [0., 0., 0., 1.]])


class SemanticReplay:
    def __init__(self, cfg, scene, dataset_config, gpu_id):
        import habitat_sim

        self.version = habitat_sim.__version__
        self.scene = Path(scene)
        self.dataset_config = Path(dataset_config)
        if not self.dataset_config.is_file():
            raise FileNotFoundError("MP3D scene dataset configuration required for semantic axes")
        self.semantic_mesh = self.scene.with_name(self.scene.stem + "_semantic.ply")
        if not self.semantic_mesh.is_file() or not self.scene.with_suffix(".house").is_file():
            raise FileNotFoundError("MP3D semantic PLY and HOUSE files are required; no box-only fallback")
        cfg = copy.deepcopy(cfg)
        cfg["habitat_sim_v0"]["gpu_device_id"] = gpu_id
        self.renderer = Renderer(cfg, scene, semantic=True, scene_dataset_config=self.dataset_config)
        self.objects = {}
        for obj in self.renderer.sim.semantic_scene.objects:
            if obj is not None and obj.semantic_id > 0:
                self.objects[int(obj.semantic_id)] = {
                    "semantic_id": int(obj.semantic_id), "instance_id": obj.id,
                    "category": obj.category.name() if obj.category is not None else None}
        if not self.objects:
            self.close()
            raise ValueError("scene has no bindable semantic objects")

    def observe(self, frame, saved_depth, saved_valid):
        import quaternion

        pose = np.asarray(frame["world_from_body"])
        rotation = quaternion.from_rotation_matrix(pose[:3, :3])
        self.renderer.set_agent_state(pose[:3, 3], [rotation.x, rotation.y, rotation.z, rotation.w])
        obs = self.renderer.get_observations_at()
        error = np.abs(obs["depth"] - saved_depth)
        usable = saved_valid & np.isfinite(obs["depth"])
        if not usable.any():
            raise ValueError("no valid depth for semantic alignment check")
        agreement = float((error[usable] <= .02 + .01 * saved_depth[usable]).mean())
        if agreement < .995:
            raise ValueError(f"semantic replay does not match saved camera/depth: agreement={agreement:.5f}")
        return np.asarray(obs["semantic"], dtype=np.int32), agreement

    def close(self):
        self.renderer.close()


def extract_object_mesh(path, semantic_id):
    """Memory-map the known MP3D binary PLY layout, copying only one object's faces.

    Reject different layouts instead of silently misreading coordinates or IDs.
    The source scene is never changed or replaced with a newly inserted object.
    """
    path = Path(path)
    with path.open("rb") as stream:
        header = []
        for _ in range(100):
            line = stream.readline().decode("ascii").strip()
            header.append(line)
            if line == "end_header":
                break
        else:
            raise ValueError("invalid PLY header")
        offset = stream.tell()
    filtered = [s for s in header if not s.startswith("comment ")]
    try:
        nv = int(next(s for s in filtered if s.startswith("element vertex ")).split()[-1])
        nf = int(next(s for s in filtered if s.startswith("element face ")).split()[-1])
    except (StopIteration, ValueError):
        raise ValueError("missing PLY vertex/face counts") from None
    expected = ["ply", "format binary_little_endian 1.0", f"element vertex {nv}",
                "property float x", "property float y", "property float z",
                "property uchar red", "property uchar green", "property uchar blue",
                f"element face {nf}", "property list uchar int vertex_indices",
                "property int object_id", "end_header"]
    if filtered != expected or nv < 1 or nf < 1:
        raise ValueError("unsupported MP3D semantic PLY layout")
    vertex_type = np.dtype([("xyz", "<f4", (3,)), ("rgb", "u1", (3,))])
    face_type = np.dtype([("count", "u1"), ("vertices", "<i4", (3,)), ("object_id", "<i4")])
    if path.stat().st_size != offset + nv * vertex_type.itemsize + nf * face_type.itemsize:
        raise ValueError("PLY is not an all-triangle MP3D mesh")
    vertices = np.memmap(path, dtype=vertex_type, mode="r", offset=offset, shape=(nv,))
    faces = np.memmap(path, dtype=face_type, mode="r",
                      offset=offset + nv * vertex_type.itemsize, shape=(nf,))
    selected = []
    for start in range(0, nf, 1_000_000):
        chunk = faces[start:start + 1_000_000]
        if not np.all(chunk["count"] == 3):
            raise ValueError("non-triangular PLY face")
        selected.append(chunk["vertices"][chunk["object_id"] == semantic_id])
    selected = np.concatenate(selected)
    if not len(selected):
        raise ValueError("bound semantic ID has no mesh faces")
    original_ids, remap = np.unique(selected, return_inverse=True)
    if original_ids.min() < 0 or original_ids.max() >= nv:
        raise ValueError("invalid PLY face vertex index")
    xyz = vertices["xyz"][original_ids].astype(np.float64)
    if not np.isfinite(xyz).all():
        raise ValueError("nonfinite object vertices")
    world = (xyz @ WORLD_FROM_MP3D[:3, :3].T).astype(np.float32)
    return {"vertices_world": world, "colors_rgb": vertices["rgb"][original_ids].copy(),
            "faces": remap.reshape(-1, 3).astype(np.int32),
            "source_vertex_ids": original_ids, "world_from_mp3d": WORLD_FROM_MP3D,
            "aabb_world": np.stack([world.min(0), world.max(0)])}
