"""Search the last eight frames chronologically for one bindable final destination."""

from pathlib import Path

import numpy as np

from data_pipeline.collect_r2r import sha256, write_json
from data_pipeline.doubao import validate_detection
from data_pipeline.pointing import bind_instance, bind_stop_location, object_point


def tail_frame_ids(count, window=8):
    if count < 1 or window < 1:
        raise ValueError("frame count and search window must be positive")
    return list(range(max(0, count - window), count))


def find_destination(source, destination, episode, frames, config, grounder, replay=None):
    """Stop at the first confident detection with a valid 3D binding and anchor point.

    A missed detection, low confidence, or failed geometric binding advances to
    the next frame. API/scene failures still fail the run instead of becoming
    negative training labels. No identity is switched once a target is selected.
    """
    source, destination = Path(source), Path(destination)
    from data_pipeline.annotate_r2r import draw_preview

    candidates = tail_frame_ids(len(frames), config.opos_search_frames)
    search = dict(candidate_frame_ids=candidates, order="ascending_chronological",
                  selection="first_confident_bindable_destination", attempts=[], selected_frame_id=None)
    fallback = dict(bound=False, reason="no_reliable_destination_in_tail")
    result = dict(binding=fallback, mesh=None, semantic=None, alignment=None, search=search)
    terminal_world = frames[-1]["world_from_body"]
    terminal_world = np.asarray(terminal_world)[:3, 3]
    K = np.asarray(episode["camera"]["K"])
    (destination / "detections").mkdir()
    for t in candidates:
        frame = frames[t]
        cache_path = destination / "detections" / f"{t:06d}.json"
        record = grounder.identify(source / frame["rgb"], episode["instruction"], cache_path)
        detection = validate_detection(record["detection"])
        if not cache_path.exists():
            write_json(cache_path, record)
        draw_preview(source / frame["rgb"], destination / "detections" / f"{t:06d}.png",
                     detection=detection)
        binding = dict(bound=False, reason="no_confident_destination")
        mesh, semantic, agreement = None, None, None
        target_type = detection.get("target_type", "object") if detection["found"] else None
        if detection["found"] and detection["confidence"] >= config.min_detection_confidence:
            with np.load(source / frame["depth"], allow_pickle=False) as data:
                depth, valid = data["depth_m"], data["valid"]
            if target_type == "stop_location":
                binding = bind_stop_location(detection, terminal_world, frame, K, depth, valid, config)
            else:
                if replay is None:
                    raise ValueError("object destination requires semantic replay")
                semantic, agreement = replay.observe(frame, depth, valid)
                binding = bind_instance(detection, semantic, replay.objects, config)
                if binding["bound"]:
                    from data_pipeline.semantic_scene import extract_object_mesh

                    mesh = extract_object_mesh(replay.semantic_mesh, binding["semantic_id"])
                    anchor = object_point(semantic, binding["semantic_id"], depth, valid,
                                          frame["world_from_camera_cv"], K, config,
                                          world_bounds=mesh["aabb_world"])
                    if anchor["state"] != "point":
                        binding = dict(bound=False, reason="anchor_" + anchor["reason"])
                    else:
                        binding.update(replay.objects[binding["semantic_id"]])
                        binding.update(target_type="object", model_kind="existing_mp3d_instance_mesh",
                                       source_semantic_mesh=str(replay.semantic_mesh),
                                       source_semantic_mesh_sha256=sha256(replay.semantic_mesh),
                                       model_file="object_model.npz", aabb_world=mesh["aabb_world"].tolist(),
                                       world_from_mp3d=mesh["world_from_mp3d"].tolist())
        attempt = dict(frame_id=t, detection_file=f"detections/{t:06d}.json", found=detection["found"],
                       target_type=target_type, confidence=detection["confidence"],
                       bound=binding["bound"], reason=binding["reason"])
        search["attempts"].append(attempt)
        print(f"opos search frame={t} target={target_type} bound={binding['bound']} "
              f"reason={binding['reason']}", flush=True)
        write_json(destination / "opos_search.json", search)
        # Compatibility name, explicitly tagged with the actual candidate frame.
        write_json(destination / "doubao_detection.json", {**record, "source_frame_id": t})
        if binding["bound"]:
            binding.update(anchor_frame_id=t, label=detection["label"],
                           detection_file=f"detections/{t:06d}.json")
            if target_type == "stop_location":
                binding["target_frame_id"] = len(frames) - 1
            else:
                np.savez_compressed(destination / "object_model.npz", **mesh)
                (destination / "object_masks").mkdir()
            search["selected_frame_id"] = t
            result.update(binding=binding, mesh=mesh, semantic=semantic, alignment=agreement)
            draw_preview(source / frame["rgb"], destination / "selected_detection.png", detection=detection)
            break
    write_json(destination / "opos_search.json", search)
    return result
